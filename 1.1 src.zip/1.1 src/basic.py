import time
import re
import config

def clear_screen():
    print("\033c", end="")


#asks the user for their API key and returns it
def ask_api_key():
    print("What is your Serp API key?")
    api_key = input().strip()
    print("\033c", end="")
    ask_api_con = True
    while ask_api_con == True:
        print(f"Inputted key is {api_key}")
        print("Is this correct? (Y/N)")
        confirm_input = str(input())
        if confirm_input.strip().lower() == "y":
            ask_api_con = False
            print("\033c", end="")
        elif confirm_input.strip().lower() == "n":
            print("\033c", end="")
            print("What is your Serp API key?")
            api_key = input().strip()
            print("\033c", end="")
        else:
            print("Invalid. Please try again.")
            time.sleep(1.5)
            print("\033c", end="")
    return api_key


#returns a normalized phone number if valid, otherwise returns None. Also strips US country code if present

def normalize_phone(raw):
    digits = re.sub(r"\D", "", raw)
    if len(digits) == 11 and digits.startswith("1"):
        digits = digits[1:]     
    if len(digits) == 10:
        return digits
    return None


#aks the users for phone numbers until they enter done

def ask_phones():
    phones = []
    print("Enter phone number(s), one per line. Any format is fine. Enter 'done' when done.")
    while True:
        raw = input("Phone: ").strip()
        if raw.lower() == "done":
            break
        if raw == "":
            continue
        phone = normalize_phone(raw)
        if phone is None:
            print("  Not a valid 10-digit US number, try again.")
        elif phone in phones:
            print("  Already entered.")
        else:
            phones.append(phone)
    return phones


#asks the user for addresses until they enter done

def ask_addresses():
    addresses = []
    print("Enter address(es). Type 'done' at the Street prompt when done.")
    while True:
        street = input("Street (e.g. 123 Main St): ").strip()
        if street.lower() == "done":
            break
        if street == "":
            continue
        city = input("City: ").strip()
        while city == "":
            print("  A city is required for an address search.")
            city = input("City: ").strip()
        state = input("State (optional): ").strip()
        addresses.append({"street": street, "city": city, "state": state})
    return addresses

#returns a dictionary with the phones and addresses entered by the user, or None if they entered nothing.
#calls both ask functions, so no need to call separately in main loop

def ask_subject():
    clear_screen()
    print("You have chosen to search by:")
    if config.use_phone:
        print("  Phone")
    if config.use_address:
        print("  Address")
    print()

    phones = ask_phones() if config.use_phone else []
    addresses = ask_addresses() if config.use_address else []

    if not phones and not addresses:
        return None           

    clear_screen()
    print("You have entered:")
    for p in phones:
        print(f"  Phone:   ({p[:3]}) {p[3:6]}-{p[6:]}")
    for a in addresses:
        print(f"  Address: {a['street']}, {a['city']} {a['state']}".rstrip())
    return {"phones": phones, "addresses": addresses}

import threading
stop_event = threading.Event()
class StoppedByUser(Exception):
    pass
def check_stop():
    if stop_event.is_set():
        raise StoppedByUser()