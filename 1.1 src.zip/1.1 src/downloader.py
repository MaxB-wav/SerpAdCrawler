import requests
import time
import re
import socket
import ipaddress
import urllib.parse
import hashlib
import cache
import config
from basic import check_stop

#downloader declarations follow


DOWNLOAD_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/130.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml",
    "Accept-Language": "en-US,en;q=0.9",
}


#downloads one page to dest, following redirects one hop at a time
#every hop is run through should_skip, so a public site can't redirect the program
#onto your own network (or onto a skipped site)

def download_page(page, dest):
    page["file"] = None
    page["error"] = None
    page["final_url"] = None
    page["fetched_at"] = None
    page["from_cache"] = False
    page["truncated"] = False
    page["sha256"] = None
    url = page["url"]
    try:
        with requests.Session() as session:
            for hop in range(config.max_redirects + 1):
                reason = should_skip(url)
                if reason:
                    if hop == 0:
                        page["error"] = f"skipped: {reason}"
                    else:
                        page["error"] = f"skipped after redirect to {domain_of(url)}: {reason}"
                    return page
                if hop == 0:
                    cached = cache.get_page(url)
                    if cached:
                        info, body = cached
                        url = info["final_url"]
                        page["fetched_at"] = info["fetched_at"]
                        page["from_cache"] = True
                        break
                with session.get(url, headers=DOWNLOAD_HEADERS, timeout=15,
                                 stream=True, allow_redirects=False) as resp:
                    if resp.is_redirect:
                        url = urllib.parse.urljoin(url, resp.headers["Location"])
                        continue
                    if resp.status_code != 200:
                        page["error"] = f"HTTP {resp.status_code}"
                        return page
                    content_type = resp.headers.get("Content-Type", "")
                    if "html" not in content_type:
                        page["error"] = f"not a web page ({content_type or 'unknown type'})"
                        return page
                    body = b""
                    for chunk in resp.iter_content(64 * 1024):
                        body += chunk
                        if len(body) >= config.max_page_bytes:
                            body = body[:config.max_page_bytes]
                            page["truncated"] = True
                            break
                    break
            else:
                page["error"] = f"too many redirects (more than {config.max_redirects})"
                return page
    except requests.RequestException as e:
        page["error"] = type(e).__name__
        return page
    page["final_url"] = url
    if not page["from_cache"]:    
        page["fetched_at"] = cache.now_iso()         
        cache.put_page(page["url"], url, body, page["fetched_at"]) 
    dest.write_bytes(body)
    page["file"] = str(dest)
    page["sha256"] = hashlib.sha256(body).hexdigest()
    return page

#downloads all pages from search()

def download_all(pages, folder):
    folder.mkdir(parents=True, exist_ok=True)
    for i, page in enumerate(pages, 1):
        check_stop()
        safe_name = re.sub(r"[^a-z0-9.-]", "_", domain_of(page["url"]))[:60]
        download_page(page, folder / f"{i:03d}_{safe_name}.html")
        status = "ok" if page["file"] else page["error"]
        print(f"  [{i}/{len(pages)}] {domain_of(page['url'])}: {status}")
        if page["file"] and not page["from_cache"]:
            time.sleep(config.download_delay)
    return pages

#cleans URL

def domain_of(url):
    host = urllib.parse.urlsplit(url).hostname or ""
    return host.lower().removeprefix("www.")

#if a URL is skipped, explains why, otherwise returns None
#KNOWN GAP (low risk): this checks the address the site has now, but requests looks the name up
#again when it connects. A site that runs its own DNS could answer with a public address here
#and a private one a moment later. At worst that sends one plain GET request into the local
#network, and the response never leaves this machine. Revisit if this runs on a server/cloud VM
#or if fetched pages are ever shown to other users. Full fix: connect to the exact IP checked here.

def should_skip(url):
    parts = urllib.parse.urlsplit(url)
    if parts.scheme not in ("http", "https"):
        return "not a web link"
    if _is_google_redirect(url):
        return "Google would not give the real address for this link"
    dom = domain_of(url)
    if any(dom == d or dom.endswith("." + d) for d in config.skip_domains):
        return "mainstream site"
    if re.search(r"\.(pdf|docx?|xlsx?|csv|zip|json|xml|jpe?g|png|gif)$", parts.path, re.I):
        return "not a web page"
    #search results are untrusted: never let a result point the program at your own network
    try:
        for info in socket.getaddrinfo(parts.hostname, None):
            if not ipaddress.ip_address(info[4][0]).is_global:
                return "points to a private network address"
    except (socket.gaierror, ValueError):
        return "site does not exist"
    return None


#True for Google's wrapped result links (google.com/goto?url=... or google.com/url?...)
#since Oct 2026 SerpApi often returns these instead of the real page address
#ONGOING ISSUE CHECK BACK PERIODICALLY. If SerpAPI stops returning these, this function can be 
#safely deleted and the code that calls it simplified. However, if they do fix it and this 
#function is not deleted, it will still work correctly, but it will be slower

def _is_google_redirect(url):
    parts = urllib.parse.urlsplit(url)
    host = (parts.hostname or "").lower()
    return (host == "google.com" or host.endswith(".google.com")) and parts.path in ("/goto", "/url")