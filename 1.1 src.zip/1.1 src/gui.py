#SerpAdCrawler window. Run this file (or the .exe built from it) instead of Main.py
#THIS FILE IS AI-GENERATED (Claude Opus 5.5) AND MAY NEED TO BE REVIEWED FOR ACCURACY AND SECURITY
#
#how it fits together:
# - the window runs on the main thread. A search runs on a second (worker) thread so the window never freezes
# - everything the backend print()s during a search is sent to the Progress box instead of a console
# - the worker never touches the window directly (tkinter isn't thread-safe). It puts messages in a queue
#   and the window picks them up every 100 ms in _poll_messages
# - settings are applied by setting the values on the config module, then saved to settings.json

import copy
import json
import os
import queue
import re
import sys
import threading
import traceback
import webbrowser
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext

#when running as an .exe, settings.json, output and cache live next to the .exe; otherwise next to this file
if getattr(sys, "frozen", False):
    APP_FOLDER = Path(sys.executable).resolve().parent
else:
    APP_FOLDER = Path(__file__).resolve().parent
os.chdir(APP_FOLDER)

import config
import basic
from basic import normalize_phone
from serpquery import SearchError, check_api_key
from pipeline import run_once
from downloader import domain_of


#settings

SETTINGS_FILE = APP_FOLDER / "settings.json"

#every editable setting in config.py: (section, name in config.py, label shown in the window, kind)
#kinds: bool = checkbox, int / float / text = box, lines = one entry per line (a list)
#keyword_categories has its own editor and isn't listed here. program_version is never editable
SETTINGS = [
    ("Search", "use_phone", "Search by phone number", "bool"),
    ("Search", "use_address", "Search by address", "bool"),
    ("Search", "query_terms", "Words added to every search\n(one per line, blank = none)", "lines"),
    ("Search", "pages_per_query", "Google result pages per query\n(each costs 1 SerpApi credit)", "int"),
    ("Downloads", "download_delay", "Seconds between page downloads", "float"),
    ("Downloads", "google_redirect_wait", "Longest wait on a Google redirect page (seconds)", "float"),
    ("Downloads", "max_page_bytes", "Largest page kept (bytes; 2097152 = 2 MB)", "int"),
    ("Downloads", "max_redirects", "Most redirects followed for one page", "int"),
    ("Downloads", "skip_domains", "Sites never downloaded\n(one per line, e.g. yelp.com)", "lines"),
    ("Scoring", "min_score", "Minimum score for a page to be kept as a hit", "int"),
    ("Scoring", "context_window", "Characters checked for keywords on each side\nof a phone/address match", "int"),
    ("Scoring", "adult_domains", "Known adult sites (one per line)", "lines"),
    ("Scoring", "adult_domain_weight", "Score added for a page on a known adult site", "int"),
    ("Output and cache", "output_folder", "Output folder", "text"),
    ("Output and cache", "use_cache", "Reuse searches and pages from earlier runs", "bool"),
    ("Output and cache", "cache_folder", "Cache folder", "text"),
    ("Output and cache", "cache_hours", "Hours a cached search or page is reused", "float"),
    ("Output and cache", "cache_max_mb", "Largest the cache folder may get (MB)", "int"),
    ("Debugging", "keep_all_pages", "Keep every downloaded page and the raw search results", "bool"),
]
EDITABLE = [name for _, name, _, _ in SETTINGS] + ["keyword_categories"]
DOMAIN_LISTS = ("skip_domains", "adult_domains")

#config.py's own values, kept before settings.json is applied so "Reset to defaults" can bring them back
DEFAULTS = {name: copy.deepcopy(getattr(config, name)) for name in EDITABLE}


#turns "https://www.Example.com/some/page" into "example.com" so domain lists match what downloader expects

def clean_domain(text):
    d = text.strip().lower()
    d = re.sub(r"^[a-z]+://", "", d)
    d = d.split("/")[0].split(":")[0]
    return d.removeprefix("www.")


#checks one keyword category. Returns a list of problems (empty if it's fine)

def category_problems(cat):
    problems = []
    if not str(cat.get("label", "")).strip():
        problems.append("a category has no name")
    if not isinstance(cat.get("weight"), int) or isinstance(cat.get("weight"), bool):
        problems.append(f'"{cat.get("label")}": weight must be a whole number')
    if not isinstance(cat.get("ignore_case"), bool):
        problems.append(f'"{cat.get("label")}": ignore_case must be true or false')
    if not isinstance(cat.get("patterns"), list) or not cat["patterns"]:
        problems.append(f'"{cat.get("label")}": needs at least one pattern')
        return problems
    for p in cat["patterns"]:
        try:
            re.compile(p)
        except re.error as e:
            problems.append(f'"{cat.get("label")}": pattern {p!r} is not valid ({e})')
    return problems


def _is_number(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool)


#loads settings.json (if there is one) onto config. Returns a warning to show, or None

def load_settings():
    if not SETTINGS_FILE.exists():
        return None
    try:
        saved = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
    except (OSError, ValueError) as e:
        return f"settings.json could not be read ({e}). Using the defaults from config.py."
    skipped = []
    for name, value in saved.items():
        if name not in EDITABLE:
            continue                                   #old or unknown setting, ignored
        default = DEFAULTS[name]
        #a saved value must be the same type as the default (whole numbers and decimals can stand in for each other)
        same_type = type(value) == type(default) or (_is_number(value) and _is_number(default))
        if name == "keyword_categories" and same_type:
            same_type = all(isinstance(c, dict) and not category_problems(c) for c in value)
        if same_type:
            setattr(config, name, value)
        else:
            skipped.append(name)
    if skipped:
        return "These saved settings were not valid and the defaults were used instead: " + ", ".join(skipped)
    return None


def save_settings():
    data = {name: getattr(config, name) for name in EDITABLE}
    SETTINGS_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")


#sends everything print()ed during a search to the window's queue, with the API key hidden

class QueueWriter:
    def __init__(self, messages, secret):
        self.messages = messages
        self.secret = secret

    def write(self, text):
        if text:
            if self.secret:
                text = text.replace(self.secret, "[key]")
            self.messages.put(("log", text))

    def flush(self):
        pass


#the window

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"SerpAdCrawler {config.program_version}")
        self.geometry("1100x750")
        self.minsize(850, 550)

        self.api_key = None                  #only set once SerpApi has accepted it
        self.running = False
        self.messages = queue.Queue()
        self.tree_info = {}                  #results table row id -> ("run", run) or ("hit", hit, run)

        self._build_key_bar()
        self.tabs = ttk.Notebook(self)
        self.tabs.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        self._build_search_tab()
        self._build_results_tab()
        self._build_settings_tab()

        self._fill_settings_form()
        self._apply_search_toggles()
        self._update_buttons()
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        self.after(100, self._poll_messages)

    #API key bar (top of the window)

    def _build_key_bar(self):
        bar = ttk.Frame(self, padding=8)
        bar.pack(fill="x")
        ttk.Label(bar, text="SerpApi key:").pack(side="left")
        self.key_var = tk.StringVar()
        self.key_entry = ttk.Entry(bar, textvariable=self.key_var, show="•", width=50)
        self.key_entry.pack(side="left", padx=6)
        self.key_entry.bind("<Return>", lambda e: self.check_key())
        self.show_key = tk.BooleanVar()
        ttk.Checkbutton(bar, text="Show", variable=self.show_key,
                        command=lambda: self.key_entry.config(show="" if self.show_key.get() else "•")
                        ).pack(side="left")
        self.check_btn = ttk.Button(bar, text="Check key", command=self.check_key)
        self.check_btn.pack(side="left", padx=6)
        self.key_status = ttk.Label(bar, text="Enter your key and click Check key.")
        self.key_status.pack(side="left", padx=6)
        self.key_var.trace_add("write", lambda *a: self._key_edited())
        self.key_entry.focus_set()

    #editing the key after it was checked means it has to be checked again

    def _key_edited(self):
        if self.api_key is not None and self.key_var.get().strip() != self.api_key:
            self.api_key = None
            self.key_status.config(text="Key changed. Click Check key.")
            self._update_buttons()

    def check_key(self):
        key = self.key_var.get().strip()
        if not key:
            self.key_status.config(text="Enter a key first.")
            return
        self.check_btn.config(state="disabled")
        self.key_status.config(text="Checking...")

        #runs on a separate thread so the window doesn't freeze while SerpApi answers
        def work():
            try:
                left = check_api_key(key)
                self.messages.put(("key_ok", key, left))
            except SearchError as e:
                self.messages.put(("key_bad", str(e)))
        threading.Thread(target=work, daemon=True).start()

    #Search tab

    def _build_search_tab(self):
        tab = ttk.Frame(self.tabs, padding=8)
        self.tabs.add(tab, text="Search")

        inputs = ttk.Frame(tab)
        inputs.pack(fill="x")
        inputs.columnconfigure(0, weight=1)
        inputs.columnconfigure(1, weight=2)

        #phone numbers: a plain text box, one per line
        self.phone_frame = ttk.LabelFrame(inputs, text="Phone numbers (one per line, any format)", padding=6)
        self.phone_frame.grid(row=0, column=0, sticky="nsew", padx=(0, 6))
        self.phone_text = tk.Text(self.phone_frame, height=8, width=24, undo=True)
        self.phone_text.pack(fill="both", expand=True)

        #addresses: street/city/state boxes, an Add button and a list
        self.addr_frame = ttk.LabelFrame(inputs, text="Addresses", padding=6)
        self.addr_frame.grid(row=0, column=1, sticky="nsew")
        row = ttk.Frame(self.addr_frame)
        row.pack(fill="x")
        self.street_var, self.city_var, self.state_var = tk.StringVar(), tk.StringVar(), tk.StringVar()
        self.addr_inputs = []
        for label, var, width in (("Street", self.street_var, 28), ("City", self.city_var, 16),
                                  ("State", self.state_var, 5)):
            ttk.Label(row, text=label).pack(side="left", padx=(0, 2))
            entry = ttk.Entry(row, textvariable=var, width=width)
            entry.pack(side="left", padx=(0, 8))
            entry.bind("<Return>", lambda e: self.add_address())
            self.addr_inputs.append(entry)
        self.add_addr_btn = ttk.Button(row, text="Add", command=self.add_address)
        self.add_addr_btn.pack(side="left")
        self.addr_tree = ttk.Treeview(self.addr_frame, columns=("street", "city", "state"),
                                      show="headings", height=5)
        for col, width in (("street", 260), ("city", 140), ("state", 50)):
            self.addr_tree.heading(col, text=col.title())
            self.addr_tree.column(col, width=width, stretch=(col == "street"))
        self.addr_tree.pack(fill="both", expand=True, pady=(6, 4))
        self.remove_addr_btn = ttk.Button(self.addr_frame, text="Remove selected", command=self.remove_address)
        self.remove_addr_btn.pack(anchor="w")

        #Run / Stop
        buttons = ttk.Frame(tab)
        buttons.pack(fill="x", pady=8)
        self.run_btn = ttk.Button(buttons, text="Run search", command=self.start_run)
        self.run_btn.pack(side="left")
        self.stop_btn = ttk.Button(buttons, text="Stop", command=self.stop_run)
        self.stop_btn.pack(side="left", padx=6)
        ttk.Button(buttons, text="Clear inputs", command=self.clear_inputs).pack(side="left", padx=6)
        self.run_status = ttk.Label(buttons, text="")
        self.run_status.pack(side="left", padx=10)

        #progress log
        log_frame = ttk.LabelFrame(tab, text="Progress", padding=4)
        log_frame.pack(fill="both", expand=True)
        self.log = scrolledtext.ScrolledText(log_frame, height=12, state="disabled", wrap="word",
                                             font=("Consolas", 9))
        self.log.pack(fill="both", expand=True)

    def add_address(self):
        street, city, state = (v.get().strip() for v in (self.street_var, self.city_var, self.state_var))
        if not street:
            return
        if not city:
            messagebox.showwarning("City needed", "A city is required for an address search.", parent=self)
            return
        self.addr_tree.insert("", "end", values=(street, city, state))
        for v in (self.street_var, self.city_var, self.state_var):
            v.set("")
        self.addr_inputs[0].focus_set()

    def remove_address(self):
        for item in self.addr_tree.selection():
            self.addr_tree.delete(item)

    def clear_inputs(self):
        self.phone_text.delete("1.0", "end")
        for item in self.addr_tree.get_children():
            self.addr_tree.delete(item)

    #greys out the phone or address box when that kind of search is turned off in Settings

    def _apply_search_toggles(self):
        self.phone_text.config(state="normal" if config.use_phone else "disabled",
                               background="white" if config.use_phone else "#e8e8e8")
        state = "normal" if config.use_address else "disabled"
        for w in self.addr_inputs + [self.add_addr_btn, self.remove_addr_btn]:
            w.config(state=state)
        self.phone_frame.config(text="Phone numbers (one per line, any format)" +
                                ("" if config.use_phone else " - turned off in Settings"))
        self.addr_frame.config(text="Addresses" + ("" if config.use_address else " - turned off in Settings"))

    #reads the inputs into the same subject dictionary basic.ask_subject() made. Returns None if not usable

    def _collect_subject(self):
        phones, bad = [], []
        if config.use_phone:
            for line in self.phone_text.get("1.0", "end").splitlines():
                if not line.strip():
                    continue
                phone = normalize_phone(line)
                if phone is None:
                    bad.append(line.strip())
                elif phone not in phones:
                    phones.append(phone)
        if bad:
            messagebox.showwarning("Check the phone numbers",
                                   "These are not valid 10-digit US numbers:\n\n" + "\n".join(bad), parent=self)
            return None
        addresses = []
        if config.use_address:
            for item in self.addr_tree.get_children():
                street, city, state = self.addr_tree.item(item, "values")
                addresses.append({"street": street, "city": city, "state": state})
        if not phones and not addresses:
            messagebox.showinfo("Nothing to search", "Enter at least one phone number or address.", parent=self)
            return None
        return {"phones": phones, "addresses": addresses}

    def start_run(self):
        if self.running or self.api_key is None:
            return
        subject = self._collect_subject()
        if subject is None:
            return
        basic.stop_event.clear()
        self.running = True
        self.run_status.config(text="Running...")
        self._update_buttons()
        self._log("\n" + "=" * 70 + "\n")
        #a list, so a CSV of many subjects can use the same worker later
        threading.Thread(target=self._run_worker, args=([subject],), daemon=True).start()

    def stop_run(self):
        if self.running:
            basic.stop_event.set()
            self.run_status.config(text="Stopping after the current step...")
            self.stop_btn.config(state="disabled")

    #runs on the worker thread: runs every subject and reports back through the queue

    def _run_worker(self, subjects):
        old_stdout = sys.stdout
        sys.stdout = QueueWriter(self.messages, self.api_key)
        try:
            for n, subject in enumerate(subjects, 1):
                basic.check_stop()
                if len(subjects) > 1:
                    print(f"\n=== Subject {n} of {len(subjects)} ===")
                try:
                    hits, pages, run_folder, manifest_hash = run_once(subject, self.api_key)
                except SearchError as e:
                    print(f"Search failed: {e}")
                    continue
                self.messages.put(("result", subject, hits, pages, run_folder, manifest_hash))
        except basic.StoppedByUser:
            print("\nStopped. The unfinished run's folder has no report.json or manifest.")
        except Exception:
            print("\nUnexpected error. Please send this to whoever maintains the program:\n")
            print(traceback.format_exc())
        finally:
            sys.stdout = old_stdout
            self.messages.put(("finished",))

    #picks up messages from the worker threads (runs on the main thread every 100 ms)

    def _poll_messages(self):
        try:
            while True:
                msg = self.messages.get_nowait()
                kind = msg[0]
                if kind == "log":
                    self._log(msg[1])
                elif kind == "result":
                    self._add_run(*msg[1:])
                elif kind == "finished":
                    self.running = False
                    self.run_status.config(text="Stopped." if basic.stop_event.is_set() else "Done.")
                    self._update_buttons()
                elif kind == "key_ok":
                    _, key, left = msg
                    if key == self.key_var.get().strip():
                        self.api_key = key
                        self.key_status.config(text=f"Key OK. {left} searches left.")
                    self.check_btn.config(state="normal")
                    self._update_buttons()
                elif kind == "key_bad":
                    self.key_status.config(text=msg[1])
                    self.check_btn.config(state="normal")
        except queue.Empty:
            pass
        self.after(100, self._poll_messages)

    def _log(self, text):
        self.log.config(state="normal")
        self.log.insert("end", text)
        self.log.see("end")
        self.log.config(state="disabled")

    #turns buttons on/off depending on whether the key is checked and a search is running

    def _update_buttons(self):
        can_run = self.api_key is not None and not self.running
        self.run_btn.config(state="normal" if can_run else "disabled")
        self.stop_btn.config(state="normal" if self.running else "disabled")
        self.save_btn.config(state="disabled" if self.running else "normal")
        self.reset_btn.config(state="disabled" if self.running else "normal")
        if self.api_key is None and not self.running:
            self.run_status.config(text="Check your API key to start.")
        elif self.run_status.cget("text") == "Check your API key to start.":
            self.run_status.config(text="")

    #Results tab: one row per run, with its hits underneath

    def _build_results_tab(self):
        tab = ttk.Frame(self.tabs, padding=8)
        self.tabs.add(tab, text="Results")
        panes = ttk.PanedWindow(tab, orient="vertical")
        panes.pack(fill="both", expand=True)

        top = ttk.Frame(panes)
        cols = ("score", "keywords", "matched", "url")
        self.results_tree = ttk.Treeview(top, columns=cols, show="tree headings")
        self.results_tree.heading("#0", text="Run / site")
        self.results_tree.column("#0", width=260, stretch=False)
        for col, title, width, stretch in (("score", "Score", 60, False), ("keywords", "Keywords found", 320, True),
                                           ("matched", "Matched", 200, False), ("url", "URL", 300, True)):
            self.results_tree.heading(col, text=title)
            self.results_tree.column(col, width=width, stretch=stretch)
        scroll = ttk.Scrollbar(top, orient="vertical", command=self.results_tree.yview)
        self.results_tree.configure(yscrollcommand=scroll.set)
        self.results_tree.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        self.results_tree.bind("<<TreeviewSelect>>", lambda e: self._show_details())
        self.results_tree.bind("<Double-1>", lambda e: self.open_in_browser())
        panes.add(top, weight=3)

        bottom = ttk.Frame(panes)
        buttons = ttk.Frame(bottom)
        buttons.pack(fill="x", pady=(6, 4))
        for text, command in (("Open page in browser", self.open_in_browser),
                              ("Open saved copy", self.open_saved_copy),
                              ("Open run folder", self.open_run_folder),
                              ("Copy manifest hash", self.copy_manifest_hash),
                              ("Add site to skip list", lambda: self.add_site_to("skip_domains")),
                              ("Add site to adult list", lambda: self.add_site_to("adult_domains"))):
            ttk.Button(buttons, text=text, command=command).pack(side="left", padx=(0, 6))
        self.details = scrolledtext.ScrolledText(bottom, height=10, state="disabled", wrap="word")
        self.details.pack(fill="both", expand=True)
        panes.add(bottom, weight=2)

    #adds one finished run (and its hits) to the results table and switches to it

    def _add_run(self, subject, hits, pages, run_folder, manifest_hash):
        failed = sum(1 for p in pages if p.get("error"))
        parts = [f"{len(subject['phones'])} phone(s)"] if subject["phones"] else []
        if subject["addresses"]:
            parts.append(f"{len(subject['addresses'])} address(es)")
        run = {"folder": Path(run_folder), "manifest": manifest_hash, "subject": subject,
               "pages": len(pages), "failed": failed, "hits": len(hits), "min_score": config.min_score}
        run_id = self.results_tree.insert("", "end", text=Path(run_folder).name, open=True,
                                          values=("", f"{len(hits)} hits from {len(pages)} pages "
                                                      f"({failed} failed/skipped)", ", ".join(parts), ""))
        self.tree_info[run_id] = ("run", run)
        for h in hits:
            keywords = "; ".join(f"{k['label']}: {', '.join(k['terms'])}" for k in h["keywords"])
            item = self.results_tree.insert(run_id, "end", text=domain_of(h.get("final_url") or h["url"]),
                                            values=(h["score"], keywords, ", ".join(h["matched"]), h["url"]))
            self.tree_info[item] = ("hit", h, run)
        self.results_tree.selection_set(run_id)
        self.results_tree.see(run_id)
        self.tabs.select(1)

    #the run or hit picked in the results table, or None

    def _selected(self):
        sel = self.results_tree.selection()
        return self.tree_info.get(sel[0]) if sel else None

    def _show_details(self):
        info = self._selected()
        lines = []
        if info and info[0] == "run":
            run = info[1]
            lines += [f"Run folder: {run['folder'].resolve()}",
                      f"Manifest SHA-256 (record this in the case file): {run['manifest']}",
                      f"{run['pages']} pages, {run['failed']} skipped/failed, {run['hits']} hits "
                      f"(score >= {run['min_score']})", ""]
            for p in run["subject"]["phones"]:
                lines.append(f"Phone:   ({p[:3]}) {p[3:6]}-{p[6:]}")
            for a in run["subject"]["addresses"]:
                lines.append(f"Address: {a['street']}, {a['city']} {a['state']}".rstrip())
            if not run["hits"] and run["failed"]:
                lines += ["", f"NOTE: no hits, but {run['failed']} pages could not be read. This does not mean "
                              "nothing was found; check the skipped/failed pages in report.json."]
        elif info:
            h = info[1]
            lines += [f"Title:    {h.get('title', '')}", f"URL:      {h['url']}"]
            if h.get("final_url") and h["final_url"] != h["url"]:
                lines.append(f"Ended at: {h['final_url']}")
            lines += [f"Found by: " + ", ".join(f"{f['kind']} {f['target']}" for f in h.get("found_by", [])),
                      f"Score:    {h['score']}  ({h['keyword_hits']} keyword hits)",
                      f"Matched:  {', '.join(h['matched'])}"]
            for k in h["keywords"]:
                lines.append(f"  {k['label']} (+{k['weight']}): {', '.join(k['terms'])}")
            lines.append(f"Saved:    {h.get('fetched_at') or ''}{' (from cache)' if h.get('from_cache') else ''}"
                         f"{' (cut off at max page size)' if h.get('truncated') else ''}")
            lines += ["", "Text around the match:", h.get("excerpt", "")]
        self.details.config(state="normal")
        self.details.delete("1.0", "end")
        self.details.insert("1.0", "\n".join(lines))
        self.details.config(state="disabled")

    def _selected_hit(self):
        info = self._selected()
        if not info or info[0] != "hit":
            messagebox.showinfo("Pick a hit", "Select one of the hit pages (under a run) first.", parent=self)
            return None
        return info[1]

    def open_in_browser(self):
        info = self._selected()
        if info and info[0] == "hit":
            webbrowser.open(info[1].get("final_url") or info[1]["url"])

    def open_saved_copy(self):
        h = self._selected_hit()
        if h is None:
            return
        if not h.get("file") or not Path(h["file"]).exists():
            messagebox.showinfo("No saved copy", "This page's saved copy isn't there anymore.", parent=self)
            return
        os.startfile(Path(h["file"]).resolve())

    def open_run_folder(self):
        info = self._selected()
        if info:
            run = info[1] if info[0] == "run" else info[2]
            os.startfile(run["folder"].resolve())

    def copy_manifest_hash(self):
        info = self._selected()
        if info:
            run = info[1] if info[0] == "run" else info[2]
            self.clipboard_clear()
            self.clipboard_append(run["manifest"])
            self.run_status.config(text="Manifest hash copied.")

    #adds the selected hit's site to skip_domains or adult_domains and saves settings

    def add_site_to(self, list_name):
        h = self._selected_hit()
        if h is None:
            return
        if self.running:
            messagebox.showinfo("Search running", "Settings can't change while a search is running.", parent=self)
            return
        site = domain_of(h.get("final_url") or h["url"])
        entries = getattr(config, list_name)
        if site in entries:
            messagebox.showinfo("Already listed", f"{site} is already on that list.", parent=self)
            return
        what = "never be downloaded" if list_name == "skip_domains" else \
               f"get +{config.adult_domain_weight} as a known adult site"
        if not messagebox.askyesno("Add site", f"Add {site}?\n\nIn future searches it will {what}.", parent=self):
            return
        setattr(config, list_name, entries + [site])
        save_settings()
        self._fill_settings_form()

    #Settings tab

    def _build_settings_tab(self):
        tab = ttk.Frame(self.tabs)
        self.tabs.add(tab, text="Settings")

        #Save / Undo / Reset stay at the bottom while the form above scrolls
        bar = ttk.Frame(tab, padding=8)
        bar.pack(side="bottom", fill="x")
        self.save_btn = ttk.Button(bar, text="Save settings", command=self.save_settings_form)
        self.save_btn.pack(side="left")
        ttk.Button(bar, text="Undo changes", command=self._fill_settings_form).pack(side="left", padx=6)
        self.reset_btn = ttk.Button(bar, text="Reset to defaults", command=self.reset_settings)
        self.reset_btn.pack(side="left")
        self.settings_status = ttk.Label(bar, text=f"Saved in {SETTINGS_FILE}")
        self.settings_status.pack(side="left", padx=10)

        #a scrollable area: a Canvas with a Frame inside it, and a scrollbar
        canvas = tk.Canvas(tab, highlightthickness=0)
        scroll = ttk.Scrollbar(tab, orient="vertical", command=canvas.yview)
        form = ttk.Frame(canvas, padding=8)
        form.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=form, anchor="nw")
        canvas.configure(yscrollcommand=scroll.set)
        canvas.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        #mouse wheel scrolls the form only while the mouse is over it
        wheel = lambda e: canvas.yview_scroll(int(-e.delta / 120), "units")
        canvas.bind("<Enter>", lambda e: canvas.bind_all("<MouseWheel>", wheel))
        canvas.bind("<Leave>", lambda e: canvas.unbind_all("<MouseWheel>"))

        #one box per section, one row per setting, built from the SETTINGS list
        self.setting_widgets = {}
        sections = {}
        for section, name, label, kind in SETTINGS:
            if section not in sections:
                frame = ttk.LabelFrame(form, text=section, padding=8)
                frame.pack(fill="x", pady=(0, 8))
                sections[section] = frame
            frame = sections[section]
            r = len(frame.grid_slaves(column=0))
            if kind == "bool":
                var = tk.BooleanVar()
                ttk.Checkbutton(frame, text=label, variable=var).grid(row=r, column=0, columnspan=2,
                                                                      sticky="w", pady=2)
                self.setting_widgets[name] = (kind, var)
                continue
            ttk.Label(frame, text=label).grid(row=r, column=0, sticky="nw", pady=2, padx=(0, 12))
            if kind == "lines":
                widget = tk.Text(frame, height=4, width=40)
                widget.grid(row=r, column=1, sticky="w", pady=2)
                self.setting_widgets[name] = (kind, widget)
            else:
                var = tk.StringVar()
                ttk.Entry(frame, textvariable=var, width=40 if kind == "text" else 12).grid(
                    row=r, column=1, sticky="w", pady=2)
                self.setting_widgets[name] = (kind, var)

        self._build_category_editor(form)

    #keyword categories: a list on the left, the selected category's details on the right

    def _build_category_editor(self, parent):
        box = ttk.LabelFrame(parent, text="Keyword categories (each adds its weight once if any pattern "
                                          "is found near the phone/address)", padding=8)
        box.pack(fill="x", pady=(0, 8))
        self.cat_tree = ttk.Treeview(box, columns=("weight", "case"), show="tree headings", height=7)
        self.cat_tree.heading("#0", text="Category")
        self.cat_tree.heading("weight", text="Weight")
        self.cat_tree.heading("case", text="Ignore case")
        self.cat_tree.column("#0", width=230)
        self.cat_tree.column("weight", width=60, anchor="center")
        self.cat_tree.column("case", width=80, anchor="center")
        self.cat_tree.grid(row=0, column=0, rowspan=6, sticky="ns", padx=(0, 12))
        self.cat_tree.bind("<<TreeviewSelect>>", lambda e: self._show_category())

        self.cat_label, self.cat_weight, self.cat_case = tk.StringVar(), tk.StringVar(), tk.BooleanVar()
        ttk.Label(box, text="Name").grid(row=0, column=1, sticky="w")
        ttk.Entry(box, textvariable=self.cat_label, width=36).grid(row=0, column=2, sticky="w")
        ttk.Label(box, text="Weight").grid(row=1, column=1, sticky="w")
        ttk.Entry(box, textvariable=self.cat_weight, width=8).grid(row=1, column=2, sticky="w")
        ttk.Checkbutton(box, text="Ignore capitals", variable=self.cat_case).grid(row=2, column=2, sticky="w")
        ttk.Label(box, text="Patterns\n(regex, one per line)").grid(row=3, column=1, sticky="nw")
        self.cat_patterns = tk.Text(box, height=5, width=60, font=("Consolas", 9))
        self.cat_patterns.grid(row=3, column=2, sticky="w")
        buttons = ttk.Frame(box)
        buttons.grid(row=4, column=2, sticky="w", pady=6)
        ttk.Button(buttons, text="Update selected", command=self.update_category).pack(side="left")
        ttk.Button(buttons, text="Add as new", command=lambda: self.update_category(new=True)).pack(
            side="left", padx=6)
        ttk.Button(buttons, text="Delete selected", command=self.delete_category).pack(side="left")
        ttk.Label(box, text="Category changes take effect when you click Save settings.",
                  foreground="gray").grid(row=5, column=2, sticky="w")

    def _refresh_category_list(self):
        self.cat_tree.delete(*self.cat_tree.get_children())
        for i, cat in enumerate(self.categories):
            self.cat_tree.insert("", "end", iid=str(i), text=cat["label"],
                                 values=(cat["weight"], "yes" if cat["ignore_case"] else "no"))

    def _show_category(self):
        sel = self.cat_tree.selection()
        if not sel:
            return
        cat = self.categories[int(sel[0])]
        self.cat_label.set(cat["label"])
        self.cat_weight.set(str(cat["weight"]))
        self.cat_case.set(cat["ignore_case"])
        self.cat_patterns.delete("1.0", "end")
        self.cat_patterns.insert("1.0", "\n".join(cat["patterns"]))

    #replaces the selected category with what's in the boxes (or adds it as a new one)

    def update_category(self, new=False):
        sel = self.cat_tree.selection()
        if not new and not sel:
            messagebox.showinfo("Pick a category", "Select a category to update, or use Add as new.", parent=self)
            return
        try:
            weight = int(self.cat_weight.get().strip())
        except ValueError:
            weight = None
        cat = {"label": self.cat_label.get().strip(), "weight": weight, "ignore_case": self.cat_case.get(),
               "patterns": [p for p in self.cat_patterns.get("1.0", "end").splitlines() if p.strip()]}
        problems = category_problems(cat)
        if problems:
            messagebox.showwarning("Check the category", "\n".join(problems), parent=self)
            return
        if new:
            self.categories.append(cat)
        else:
            self.categories[int(sel[0])] = cat
        self._refresh_category_list()
        index = len(self.categories) - 1 if new else int(sel[0])
        self.cat_tree.selection_set(str(index))
        self.settings_status.config(text="Unsaved changes. Click Save settings.")

    def delete_category(self):
        sel = self.cat_tree.selection()
        if not sel:
            return
        cat = self.categories[int(sel[0])]
        if messagebox.askyesno("Delete category", f'Delete "{cat["label"]}"?', parent=self):
            del self.categories[int(sel[0])]
            self._refresh_category_list()
            self.settings_status.config(text="Unsaved changes. Click Save settings.")

    #puts the current config values into the form (also used by Undo changes)

    def _fill_settings_form(self):
        for name, (kind, widget) in self.setting_widgets.items():
            value = getattr(config, name)
            if kind == "bool":
                widget.set(bool(value))
            elif kind == "lines":
                widget.delete("1.0", "end")
                widget.insert("1.0", "\n".join(value))
            else:
                widget.set(str(value))
        self.categories = copy.deepcopy(config.keyword_categories)
        self._refresh_category_list()
        for var in (self.cat_label, self.cat_weight):
            var.set("")
        self.cat_patterns.delete("1.0", "end")
        self.settings_status.config(text=f"Saved in {SETTINGS_FILE}")

    #reads and checks the whole form. Returns {name: value}, or None after showing what's wrong

    def _read_settings_form(self):
        values, problems = {}, []
        for section, name, label, kind in SETTINGS:
            _, widget = self.setting_widgets[name]
            label = " ".join(label.split())
            if kind == "bool":
                values[name] = widget.get()
            elif kind == "lines":
                lines = [l.strip() for l in widget.get("1.0", "end").splitlines() if l.strip()]
                if name in DOMAIN_LISTS:
                    lines = list(dict.fromkeys(clean_domain(l) for l in lines))
                values[name] = lines
            elif kind == "text":
                values[name] = widget.get().strip()
                if not values[name]:
                    problems.append(f"{label}: can't be empty")
            else:
                number_type = int if kind == "int" else float
                try:
                    values[name] = number_type(widget.get().strip())
                    if values[name] < 0:
                        problems.append(f"{label}: can't be negative")
                except ValueError:
                    problems.append(f"{label}: must be a {'whole ' if kind == 'int' else ''}number")
        if values.get("pages_per_query") == 0:
            problems.append("Google result pages per query: must be at least 1")
        if not (values.get("use_phone") or values.get("use_address")):
            problems.append("Turn on at least one of: Search by phone number / Search by address")
        if problems:
            messagebox.showwarning("Check the settings", "\n".join(problems), parent=self)
            return None
        values["keyword_categories"] = copy.deepcopy(self.categories)
        return values

    def save_settings_form(self):
        if self.running:
            return
        values = self._read_settings_form()
        if values is None:
            return
        for name, value in values.items():
            setattr(config, name, value)
        try:
            save_settings()
        except OSError as e:
            messagebox.showerror("Not saved", f"The settings are in use now but could not be saved to "
                                              f"{SETTINGS_FILE}:\n{e}", parent=self)
            return
        self._fill_settings_form()                     #shows the cleaned-up values (e.g. domain lists)
        self._apply_search_toggles()
        self.settings_status.config(text="Saved.")

    def reset_settings(self):
        if self.running:
            return
        if not messagebox.askyesno("Reset to defaults", "Put every setting back to the values in config.py? "
                                   "This includes the skip/adult site lists and keyword categories.",
                                   parent=self):
            return
        for name, value in DEFAULTS.items():
            setattr(config, name, copy.deepcopy(value))
        save_settings()
        self._fill_settings_form()
        self._apply_search_toggles()
        self.settings_status.config(text="Reset to defaults and saved.")

    #closing the window

    def on_close(self):
        if self.running:
            if not messagebox.askyesno("Search running", "A search is still running. Stop it and close?",
                                       parent=self):
                return
            basic.stop_event.set()
        self.destroy()


def main():
    #sharp text on high-resolution Windows screens (otherwise Windows stretches the window and it looks blurry)
    try:
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass
    warning = load_settings()
    app = App()
    if warning:
        messagebox.showwarning("Settings", warning, parent=app)
    app.mainloop()


if __name__ == "__main__":
    main()
