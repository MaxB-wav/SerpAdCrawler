import requests
import time
import urllib.parse
import re
import cache
import config
from downloader import DOWNLOAD_HEADERS, domain_of, _is_google_redirect
from basic import check_stop

#SERP API declarations follow

SERPAPI_URL = "https://serpapi.com/search.json"
SERPAPI_ACCOUNT_URL = "https://serpapi.com/account.json"

#every raw SerpApi response from the current run (saved in report.json when keep_all_pages is on)
_raw_responses = []


#raised when a search can't be completed

class SearchError(Exception):
    pass


#formats a phone number in the format XXX-XXX-XXXX for the search

def format_phone(digits):
    return f"{digits[:3]}-{digits[3:6]}-{digits[6:]}"


#cleans the street address 

def _clean_street(street):
    s = re.sub(r"\b(?:ste|suite|apt|unit|bldg|rm|spc)\b\.?\s*[\w-]*|#\s*[\w-]*", "", street, flags=re.I)
    s = re.sub(r"[^\w\s]", "", s)
    return re.sub(r"\s+", " ", s).strip()


#checks the Serp API key
#returns number of searches left

def check_api_key(api_key):
    try:
        resp = requests.get(SERPAPI_ACCOUNT_URL, params={"api_key": api_key}, timeout=15)
    except requests.RequestException:
        raise SearchError("Could not reach SerpApi. Check your internet connection.")
    if resp.status_code in (401, 403):
        raise SearchError("SerpApi rejected the key.")
    if resp.status_code != 200:
        raise SearchError(f"SerpApi account check failed (HTTP {resp.status_code}).")
    return resp.json().get("total_searches_left", 0)


#builds the query from Config.query_terms

def _terms_group():
    if not config.query_terms:
        return ""
    return " (" + " OR ".join(f'"{t}"' for t in config.query_terms) + ")"

#takes the data from subject dictionary and compiles them to readable queries

def build_queries(subject):
    queries = []
    for phone in subject["phones"]:
        queries.append({
            "query": f'"{format_phone(phone)}"' + _terms_group(),
            "kind": "phone",
            "target": phone,
        })
    for a in subject["addresses"]:
        parts = [f'"{_clean_street(a["street"])}"', f'"{a["city"]}"']
        if a["state"]:
            parts.append(f'"{a["state"]}"')
        queries.append({
            "query": " ".join(parts) + _terms_group(),
            "kind": "address",
            "target": f'{a["street"]}, {a["city"]} {a["state"]}'.strip(),
        })
    return queries


#runs query against SerpAPI and returns results
#retries on temporary errors

def serp_search(query, api_key, start=0, retries=3):
    params = {
        "engine": "google",
        "q": query,
        "api_key": api_key,
        "gl": "us",
        "hl": "en",
        "safe": "off",
        "start": start,
    }
    cached = cache.get_search(params)
    if cached is not None:
        _raw_responses.append(cached)
        return [] if "error" in cached else _collect_results(cached)
    last_error = "unknown error"
    for attempt in range(retries):
        try:
            resp = requests.get(SERPAPI_URL, params=params, timeout=30)
        except requests.RequestException as e:
            last_error = type(e).__name__
            time.sleep(2 ** attempt)
            continue

        if resp.status_code in (401, 403):
            raise SearchError("SerpApi rejected the key.")
        if resp.status_code == 429 or resp.status_code >= 500:
            last_error = f"HTTP {resp.status_code}"
            time.sleep(2 ** attempt)
            continue
        if resp.status_code != 200:
            raise SearchError(f"SerpApi returned HTTP {resp.status_code}.")

        try:
            data = resp.json()
        except ValueError:
            last_error = "response was not valid JSON"
            time.sleep(2 ** attempt)
            continue
        _raw_responses.append(data)
        if "error" in data:
            #SerpApi reports "no results" as an error; that is a normal, empty result
            if "hasn't returned any results" in data["error"]:
                cache.put_search(params, data)
                return []
            raise SearchError("SerpApi: " + data["error"].replace(api_key, "[key]"))
        cache.put_search(params, data)
        return _collect_results(data)

    raise SearchError(f"Search failed after {retries} attempts ({last_error}).")


#pulls every usable link out of one SerpApi response: [{"url", "title", "snippet", "source"}, ...]
#besides the normal results, Google often puts the business itself in the side panel (knowledge_graph)
#or the map listings (local_results) with a direct link to its website

def _collect_results(data):
    results = []
    for r in data.get("organic_results", []):
        if r.get("link"):
            results.append({"url": r["link"], "title": r.get("title", ""),
                            "snippet": r.get("snippet", ""), "source": "organic"})

    kg = data.get("knowledge_graph") or {}
    if kg.get("website"):
        results.append({"url": kg["website"], "title": kg.get("title", ""),
                        "snippet": f'{kg.get("type", "")} {kg.get("phone", "")} {kg.get("address", "")}'.strip(),
                        "source": "business panel"})

    local = data.get("local_results") or []
    if isinstance(local, dict):
        local = local.get("places", [])
    for place in local:
        website = place.get("website") or (place.get("links") or {}).get("website")
        if website:
            results.append({"url": website, "title": place.get("title", ""),
                            "snippet": f'{place.get("type", "")} {place.get("phone", "")} {place.get("address", "")}'.strip(),
                            "source": "map listing"})
    return results


#turns a Google redirect link into the real page address. Returns the real URL, or None if Google won't say.
#Google answers either with a redirect (Location header) or a "you are being redirected" page
#with a timed meta refresh to a new link; that one is waited out and followed

def resolve_link(url, max_steps=4):
    if not _is_google_redirect(url):
        return url
    for step in range(max_steps):
        try:
            resp = requests.get(url, headers=DOWNLOAD_HEADERS, timeout=15, allow_redirects=False)
        except requests.RequestException:
            return None
        if resp.is_redirect and resp.headers.get("Location"):
            url = urllib.parse.urljoin(url, resp.headers["Location"])
        elif resp.status_code == 200:
            refresh = re.search(r'<meta[^>]+content="(\d+)\s*;\s*url=([^"]+)"[^>]*http-equiv="refresh"'
                                r'|<meta[^>]+http-equiv="refresh"[^>]+content="(\d+)\s*;\s*url=([^"]+)"',
                                resp.text, re.I)
            if not refresh:
                return None
            wait = int(refresh.group(1) or refresh.group(3))
            target = (refresh.group(2) or refresh.group(4)).replace("&amp;", "&")
            time.sleep(min(wait, config.google_redirect_wait))
            url = urllib.parse.urljoin(url, target)
        else:
            return None
        if not _is_google_redirect(url):
            return url
    return None


#runs every query for the subject and merges the results into one list, one entry per URL
#Google redirect links are resolved to the real page address first, so the same page found twice is merged

def search(subject, api_key):
    queries = build_queries(subject)
    by_url = {}
    for q in queries:
        check_stop()
        print(f"Searching {q['kind']}: {q['target']}")
        for page_num in range(config.pages_per_query):
            results = serp_search(q["query"], api_key, start=page_num * 10)
            print(f"  page {page_num + 1}: {len(results)} results")
            for r in results:
                check_stop()
                real_url = resolve_link(r["url"])
                if real_url is None:
                    print(f"    could not get the real address for: {r['title'][:60]}")
                    real_url = r["url"]                #kept so the report shows it; download will skip it
                elif real_url != r["url"]:
                    print(f"    {domain_of(real_url)}")
                url = real_url.split("#")[0]           #same page, different anchor = same page
                found = {"kind": q["kind"], "target": q["target"]}
                if url in by_url:
                    if found not in by_url[url]["found_by"]:
                        by_url[url]["found_by"].append(found)
                else:
                    by_url[url] = {"url": url, "google_link": r["url"] if r["url"] != url else None,
                                   "title": r["title"], "snippet": r["snippet"], "source": r["source"],
                                   "found_by": [found]}
            organic = sum(1 for r in results if r["source"] == "organic")
            if organic < 10:
                break                                  
    return list(by_url.values())


