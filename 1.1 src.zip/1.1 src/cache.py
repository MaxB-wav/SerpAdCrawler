import hashlib
import json
import time
from datetime import datetime
from pathlib import Path
import config

#cache declarations follow
#saves SerpApi responses and downloaded pages so a rerun within cache_hours costs no credits
#and doesn't download the same pages again. Only successful results are saved, so failures are always retried


#file path for one cached item. The key is hashed so any URL or query becomes a safe file name

def _path(kind, key, ext):
    name = hashlib.sha256(key.encode("utf-8")).hexdigest()
    return Path(config.cache_folder) / kind / f"{name}{ext}"


#True if the file exists and is younger than cache_hours

def _fresh(path):
    return path.exists() and time.time() - path.stat().st_mtime < config.cache_hours * 3600


#the search settings that make a search unique. The API key is left out so it is never written to disk

def _search_key(params):
    return json.dumps({k: v for k, v in params.items() if k != "api_key"}, sort_keys=True)


#returns a saved SerpApi response for these search settings, or None

def get_search(params):
    if not config.use_cache:
        return None
    path = _path("search", _search_key(params), ".json")
    if not _fresh(path):
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def put_search(params, data):
    if not config.use_cache:
        return
    path = _path("search", _search_key(params), ".json")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data), encoding="utf-8")


#returns (info, body) for a saved page, or None. info holds final_url and when it was downloaded

def get_page(url):
    if not config.use_cache:
        return None
    info_path = _path("pages", url, ".json")
    body_path = info_path.with_suffix(".html")
    if not (_fresh(info_path) and body_path.exists()):
        return None
    try:
        return json.loads(info_path.read_text(encoding="utf-8")), body_path.read_bytes()
    except (OSError, ValueError):
        return None


#saves a downloaded page. The body is written first, so a page is never listed without its content

def put_page(url, final_url, body, fetched_at):
    if not config.use_cache:
        return
    info_path = _path("pages", url, ".json")
    info_path.parent.mkdir(parents=True, exist_ok=True)
    info_path.with_suffix(".html").write_bytes(body)
    info_path.write_text(json.dumps({"url": url, "final_url": final_url, "fetched_at": fetched_at}),
                         encoding="utf-8")


#deletes anything older than cache_hours, then the oldest files until the cache is under cache_max_mb
#runs at the start of every run, so the cache never grows past one run's worth over the limit

def clean_cache():
    root = Path(config.cache_folder)
    if not root.exists():
        return
    files = []
    cutoff = time.time() - config.cache_hours * 3600
    for f in root.rglob("*"):
        if not f.is_file():
            continue
        try:
            st = f.stat()
            if st.st_mtime < cutoff:
                f.unlink()
            else:
                files.append((st.st_mtime, st.st_size, f))
        except OSError:
            pass
    total = sum(size for _, size, _ in files)
    limit = config.cache_max_mb * 1024 * 1024
    for _, size, f in sorted(files, key=lambda x: x[0]):
        if total <= limit:
            break
        try:
            f.unlink()
            total -= size
        except OSError:
            pass


def now_iso():
    return datetime.now().isoformat(timespec="seconds")
