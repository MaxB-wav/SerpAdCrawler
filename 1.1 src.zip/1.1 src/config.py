#config file
#version of this program, saved in every report and manifest. Raise it whenever the code changes
program_version = "1.1"

#query settings

#use phone for lookup?
use_phone = True
#use address for lookup?
use_address = True
#words added to every search to focus on ad/review sites. Set to [] to search the phone/address alone
query_terms = []
#how many pages of Google results to get per query (each page is ~10 results and costs 1 SerpApi credit)
pages_per_query = 1


#download and search settings

#folder where each run's pages and report are saved (a new timestamped subfolder per run)
output_folder = "output"

#seconds to wait between page downloads (to avoid being blocked)
download_delay = 0.5

#longest wait (seconds) on Google's "you are being redirected" page when finding a result's real address
google_redirect_wait = 8

#pages bigger than this are cut off (bytes)
max_page_bytes = 2 * 1024 * 1024

#sites that aren't downloaded. Default is none
skip_domains = []

#most redirects followed for one page before giving up (each one is checked like the original link)
max_redirects = 5


#analyze settings

#characters on each side of a phone/address match that get checked for keywords
context_window = 500

#a page needs at least this score to be kept as a hit; lower-scoring pages are deleted
min_score = 15

#keyword categories. Each category adds its weight ONCE if any of its patterns is found near the subject
#"ignore_case": False means capitals must match exactly
keyword_categories = [
    {
        "label": "Explicit sexual service terms",
        "weight": 45,
        "ignore_case": True,
        "patterns": [r"\b(?:happy\s*ending|hand\s*job|blow\s*job|body\s*to\s*body|nuru\s*massage)\b"],
    },
    {
        #abbreviations are case-sensitive on purpose: lowercase "cim"/"daty" show up inside ordinary words and URLs
        "label": "Explicit abbreviations",
        "weight": 45,
        "ignore_case": False,
        "patterns": [r"\b(?:BBBJ|BBFS|BBBJnqns|BBBJTC|CIM|DATY|MSOG)\b"],
    },
    {
        "label": "Adult service terminology",
        "weight": 15,
        "ignore_case": True,
        "patterns": [r"\b(?:incall|in-call|outcall|out-call|girlfriend\s*experience|pornstar\s*experience|sensual\s*massage)\b"],
    },
    {
        "label": "Service pricing",
        "weight": 10,
        "ignore_case": True,
        "patterns": [
            r"\$\s*\d{2,3}\s*(?:/|per)?\s*(?:hr|hour|hhr|half|30\s*min|15\s*min)\b",
            r"\b(?:half\s*hour|full\s*hour|hhr|1hr)\s*[:.]?\s*\$\d{2,}",
        ],
    },
    {
        "label": "Staff rotation language",
        "weight": 10,
        "ignore_case": True,
        "patterns": [r"\bnew\s*girls?\s*(?:every|each)\s*(?:week|day|month)\b"],
    },
]

#sites known to carry adult ads. A page on one of these (or a subdomain) that mentions the subject
#gets adult_domain_weight added and is listed as "Known adult site" with its keywords. Default is none
adult_domains = []
adult_domain_weight = 15

#cache settings

#reuse search results and pages from earlier runs (set to False to always get fresh copies)
use_cache = True
#folder where cached searches and pages are kept
cache_folder = "cache"
#how long (hours) a cached search or page is used before it's fetched again
cache_hours = 24
#largest the cache folder may get (MB); the oldest files are deleted first
cache_max_mb = 500


#testing and debugging settings

#keep every downloaded page and the raw search results (for checking why a run found nothing)
keep_all_pages = False