import json
import hashlib
import getpass
import platform
import types
import requests
import config
import cache
from datetime import datetime
from pathlib import Path
from serpquery import _raw_responses, build_queries, search
from analyzer import analyze_page, rank, cleanup
from downloader import download_all

#pipeline declarations follow

#prints a summary and the ranked hits with the keywords found
#THIS CODE BLOCK IS PARTIALLY AI-GENERATED (Claude Opus 5.5) AND MAY NEED TO BE REVIEWED FOR ACCURACY AND SECURITY

def print_results(pages, hits, run_folder):
    failed = sum(1 for p in pages if p["error"])
    matched = sum(1 for p in pages if p["matched"])
    print(f"\n{len(pages)} pages: {len(pages) - failed} downloaded, {failed} skipped/failed, "
          f"{matched} mention the subject, {len(hits)} hits (score >= {config.min_score}).")
    for i, h in enumerate(hits, 1):
        print(f"\n#{i}  score {h['score']}  ({h['keyword_hits']} keyword hits)")
        print(f"    {h['url']}")
        print(f"    matched: {', '.join(h['matched'])}")
        for k in h["keywords"]:
            print(f"    {k['label']} (+{k['weight']}): {', '.join(k['terms'])}")
    if hits:
        print(f"\nHit pages saved in {run_folder / 'pages'}")
    if not hits and failed:
        print(f"\nNOTE: no hits, but {failed} of {len(pages)} pages could not be read. "
              f"This does not mean nothing was found; check the skipped/failed pages in report.json.")


#saves every page's result (hits and non-hits) to report.json so a run can be checked afterwards

def save_report(run_folder, subject, pages, hits, api_key):
    run_folder.mkdir(parents=True, exist_ok=True)
    report = {
        "created": datetime.now().isoformat(timespec="seconds"),
        "subject": subject,
        "queries": [q["query"] for q in build_queries(subject)],
        "min_score": config.min_score,
        "hit_count": len(hits),
        "pages": pages,
        "raw_search_responses": _raw_responses if config.keep_all_pages else "set keep_all_pages = True to save these",
        "program_version": config.program_version,
        "run_by": getpass.getuser(),
        "computer": platform.node(),
        "python_version": platform.python_version(),
        "requests_version": requests.__version__,
        "settings": _settings_snapshot(),
    }
    text = json.dumps(report, indent=2, default=str).replace(api_key, "[key]")
    (run_folder / "report.json").write_text(text, encoding="utf-8")

    
#every setting in config.py, so the report shows exactly which keywords, weights and limits produced it

def _settings_snapshot():
    return {name: value for name, value in vars(config).items()
            if not name.startswith("_") and not isinstance(value, types.ModuleType) and not callable(value)}


#returns the SHA-256 of a file, read in pieces so large files don't fill memory

def _sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


#writes manifest.json: the SHA-256 of every file in the run folder (report.json and the saved pages)
#returns the manifest's own SHA-256. Record that hash somewhere outside this folder (the case file):
#if it still matches later, neither the manifest nor any file it lists has been changed

def write_manifest(run_folder):
    files = {}
    for f in sorted(run_folder.rglob("*")):
        if f.is_file() and f.name != "manifest.json":
            files[f.relative_to(run_folder).as_posix()] = _sha256_file(f)
    manifest = {
        "created": datetime.now().isoformat(timespec="seconds"),
        "program_version": config.program_version,
        "algorithm": "sha256",
        "files": files,
    }
    data = json.dumps(manifest, indent=2).encode("utf-8")
    (run_folder / "manifest.json").write_bytes(data)
    return hashlib.sha256(data).hexdigest()


#search>download>analyze>rank>delete non hits. Returns (hits, all_pages)

def run_once(subject, api_key):
    cache.clean_cache()
    run_folder = Path(config.output_folder) / datetime.now().strftime("%Y%m%d-%H%M%S")
    _raw_responses.clear()
    pages = search(subject, api_key)
    print(f"Found {len(pages)} unique pages. Downloading...")
    if not pages:
        save_report(run_folder, subject, [], [], api_key)
        print(f"Report saved in {run_folder}")
        manifest_hash = write_manifest(run_folder)
        print(f"Manifest SHA-256 (record this in the case file): {manifest_hash}")
        return [], [], run_folder, manifest_hash
    download_all(pages, run_folder / "pages")
    for p in pages:
        analyze_page(p, subject)
    pages = rank(pages)
    hits = cleanup(pages)
    save_report(run_folder, subject, pages, hits, api_key)
    print_results(pages, hits, run_folder)
    print(f"Full report: {run_folder / 'report.json'}")
    manifest_hash = write_manifest(run_folder)
    print(f"Manifest SHA-256 (record this in the case file): {manifest_hash}")
    return hits, pages, run_folder, manifest_hash