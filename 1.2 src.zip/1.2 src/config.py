#config file
#version of this program, saved in every report and manifest. Raise it whenever the code changes
program_version = "1.2"

#query settings

use_phone = True
use_address = True
query_terms = ["massage"]
pages_per_query = 1

#download and search settings

output_folder = "output"
download_delay = 0.5
google_redirect_wait = 15
max_page_bytes = 2 * 1024 * 1024
skip_domains = []
max_redirects = 5

#analyze settings

context_window = 500
min_score = 15
keyword_categories = [
    {
        "label": "Explicit sexual service terms",
        "weight": 45,
        "ignore_case": True,
        "patterns": [r"\b(?:happy\s*ending|hand\s*job|blow\s*job|body\s*to\s*body|nuru\s*massage)\b"],
    },
    {
        #abbreviations are case-sensitive on purpose: lowercase "cim"/"daty" show up inside ordinary words and URLs
        "label": "Explicit abbreviations",
        "weight": 45,
        "ignore_case": False,
        "patterns": [r"\b(?:BBBJ|BBFS|BBBJnqns|BBBJTC|CIM|DATY|MSOG)\b"],
    },
    {
        "label": "Adult service terminology",
        "weight": 15,
        "ignore_case": True,
        "patterns": [r"\b(?:incall|in-call|outcall|out-call|girlfriend\s*experience|pornstar\s*experience|sensual\s*massage|mutual\s*touching|escort|body\s*rub)\b"],
    },
    {
        "label": "Service pricing",
        "weight": 10,
        "ignore_case": True,
        "patterns": [
            r"\$\s*\d{2,3}\s*(?:/|per)?\s*(?:hr|hour|hhr|half|30\s*min|15\s*min)\b",
            r"\b(?:half\s*hour|full\s*hour|hhr|1hr)\s*[:.]?\s*\$\d{2,}",
        ],
    },
    {
        "label": "Staff rotation language",
        "weight": 10,
        "ignore_case": True,
        "patterns": [r"\bnew\s*girls?\s*(?:every|each)\s*(?:week|day|month)\b"],
    },
]

adult_domains = ["rubmaps.ch"]
adult_domain_weight = 15

#cache settings

use_cache = True
cache_folder = "cache"
cache_hours = 24
cache_max_mb = 500

#testing and debugging settings

keep_all_pages = False