from serpquery import SearchError, check_api_key
from pipeline import run_once
from basic import ask_subject, ask_api_key

#keep asking until SerpApi accepts the key
while True:
    api_key = ask_api_key()
    try:
        print(f"Key OK. {check_api_key(api_key)} searches left.")
        break
    except SearchError as e:
        print(f"{e} Please try again.")

#search until the user enters nothing
try:
    while True:
        subject = ask_subject()
        if subject is None:
            break
        try:
            hits, pages, run_folder, manifest_hash = run_once(subject, api_key)
        except SearchError as e:
            print(f"Search failed: {e}")
        input("\nPress Enter for a new search...")
except KeyboardInterrupt:
    print("\nStopped.")
print("Goodbye.")