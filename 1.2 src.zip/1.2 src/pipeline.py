import json
import hashlib
import getpass
import platform
import types
import requests
import config
import cache
import textwrap
from datetime import datetime
from pathlib import Path
from serpquery import _raw_responses, build_queries, search
from analyzer import analyze_page, rank, cleanup
from downloader import download_all, domain_of

#pipeline declarations follow

def print_results(pages, hits, run_folder):
    failed = sum(1 for p in pages if p["error"])
    matched = sum(1 for p in pages if p["matched"])
    flagged = sum(1 for h in hits if h["flag"])
    print(f"\n{len(pages)} pages: {len(pages) - failed} downloaded, {failed} skipped/failed, "
          f"{matched} mention the subject, {len(hits) - flagged} hits (score >= {config.min_score}), "
          f"{flagged} flagged known adult site page(s).")
    for i, h in enumerate(hits, 1):
        if h["flag"]:
            print(f"\n#{i}  FLAGGED: {h['flag']}")
            print(f"    {h['url']}")
            continue
        print(f"\n#{i}  score {h['score']}  ({h['keyword_hits']} keyword hits)")
        print(f"    {h['url']}")
        print(f"    matched: {', '.join(h['matched'])}")
        for k in h["keywords"]:
            print(f"    {k['label']} (+{k['weight']}): {', '.join(k['terms'])}")
    if any(h["file"] for h in hits):
        print(f"\nSaved copies are in {run_folder / 'pages'}")
    if not hits and failed:
        print(f"\nNOTE: no hits, but {failed} of {len(pages)} pages could not be read. "
              f"This does not mean nothing was found; check the skipped/failed pages in report.json.")

def save_report(run_folder, subject, pages, hits, api_key):
    run_folder.mkdir(parents=True, exist_ok=True)
    report = {
        "created": datetime.now().isoformat(timespec="seconds"),
        "subject": subject,
        "queries": [q["query"] for q in build_queries(subject)],
        "min_score": config.min_score,
        "hit_count": sum(1 for h in hits if not h["flag"]),
        "flagged_count": sum(1 for h in hits if h["flag"]),
        "pages": pages,
        "raw_search_responses": _raw_responses if config.keep_all_pages else "set keep_all_pages = True to save these",
        "program_version": config.program_version,
        "run_by": getpass.getuser(),
        "computer": platform.node(),
        "python_version": platform.python_version(),
        "requests_version": requests.__version__,
        "settings": _settings_snapshot(),
    }
    text = json.dumps(report, indent=2, default=str).replace(api_key, "[key]")
    (run_folder / "report.json").write_text(text, encoding="utf-8")

#a plain-text version of the report for reading in Notepad. report.json stays the full record
def save_text_report(run_folder, subject, pages, hits, api_key):
    real_hits = [h for h in hits if not h["flag"]]
    flagged = [h for h in hits if h["flag"]]
    failed = [p for p in pages if p["error"]]
    matched = [p for p in pages if p["matched"]]
    below = [p for p in matched if p not in hits]
    rule = "=" * 78
    lines = [rule, f"SerpAdCrawler {config.program_version} - search report", rule,
             f"Created:   {datetime.now().isoformat(timespec='seconds')}",
             f"Run by:    {getpass.getuser()} on {platform.node()}",
             f"Run folder: {run_folder.resolve()}", ""]

    lines += ["SUBJECT", "-" * 7]
    if subject.get("label"):
        lines.append(f"Name/label: {subject['label']}")
    if subject.get("csv_file"):
        lines.append(f"From:       {subject['csv_file']}, row {subject['csv_row']}")
    for p in subject["phones"]:
        lines.append(f"Phone:      ({p[:3]}) {p[3:6]}-{p[6:]}")
    for a in subject["addresses"]:
        lines.append(f"Address:    {a['street']}, {a['city']} {a['state']}".rstrip())
    lines += ["", "Google searches run:"] + [f"  {q['query']}" for q in build_queries(subject)] + [""]

    lines += ["SUMMARY", "-" * 7,
              f"{len(pages)} pages found, {len(pages) - len(failed)} downloaded, {len(failed)} skipped/failed",
              f"{len(matched)} mention the subject, {len(real_hits)} hits (score {config.min_score} or more), "
              f"{len(flagged)} page(s) on known adult sites listed regardless of score", ""]
    if not real_hits and failed:
        lines += ["NOTE: no hits, but some pages could not be read. This does not mean nothing was",
                  "found; check the skipped/failed pages below.", ""]

    lines += ["HITS (highest score first)", "-" * 26]
    if not real_hits:
        lines.append("None.")
    for i, h in enumerate(real_hits, 1):
        lines += [f"#{i}  {domain_of(h.get('final_url') or h['url'])}  -  score {h['score']} "
                  f"({h['keyword_hits']} keyword hits)",
                  f"  Title:    {h.get('title', '')}",
                  f"  URL:      {h['url']}"]
        if h.get("final_url") and h["final_url"] != h["url"]:
            lines.append(f"  Ended at: {h['final_url']}")
        lines += ["  Found by: " + ", ".join(f"{f['kind']} {f['target']}" for f in h.get("found_by", [])),
                  f"  Matched:  {', '.join(h['matched'])}",
                  "  Keywords:"]
        lines += [f"    {k['label']} (+{k['weight']}): {', '.join(k['terms'])}" for k in h["keywords"]]
        lines.append(f"  Saved:    {h.get('fetched_at') or ''}"
                     f"{' (from cache)' if h.get('from_cache') else ''}"
                     f"{' (cut off at max page size)' if h.get('truncated') else ''}")
        if h.get("file"):
            lines.append(f"  Copy:     {h['file']}")
        lines.append("  Text around the match:")
        for para in (h.get("excerpt") or "").splitlines():
            lines += textwrap.wrap(para, 74, initial_indent="    ", subsequent_indent="    ") or [""]
        lines.append("")
    if flagged:
        lines += ["", "FLAGGED: KNOWN ADULT SITES (listed regardless of score)", "-" * 55]
        for h in flagged:
            lines += [f"*  {domain_of(h.get('final_url') or h['url'])}",
                      f"  Why:      {h['flag']}",
                      f"  Title:    {h.get('title', '')}",
                      f"  URL:      {h['url']}"]
            if h.get("final_url") and h["final_url"] != h["url"]:
                lines.append(f"  Ended at: {h['final_url']}")
            lines.append("  Found by: " + ", ".join(f"{f['kind']} {f['target']}" for f in h.get("found_by", [])))
            if h["matched"]:
                lines.append(f"  Matched:  {', '.join(h['matched'])}  (score {h['score']})")
            if h.get("file"):
                lines.append(f"  Copy:     {h['file']}")
            if h.get("snippet"):
                lines.append("  Google's snippet:")
                lines += textwrap.wrap(h["snippet"], 74, initial_indent="    ", subsequent_indent="    ")
            lines.append("")
    if below:
        lines += ["", f"MENTION THE SUBJECT BUT SCORED UNDER {config.min_score}", "-" * 40]
        lines += [f"  score {p['score']:>3}  {p.get('final_url') or p['url']}" for p in below]
    failed_other = [p for p in failed if not p["flag"]]     
    if failed_other:
        lines += ["", "SKIPPED OR FAILED (not checked)", "-" * 31]
        lines += [f"  {p['url']}\n      {p['error']}" for p in failed_other]

    lines += ["", rule,
              "report.json in this folder has the full details and the settings used.",
              "The manifest hash for this run is shown in the program (Copy manifest hash);",
              "record it in the case file. It covers this file too.", rule, ""]
    text = "\n".join(lines)
    if api_key:
        text = text.replace(api_key, "[key]")
    (run_folder / "report.txt").write_text(text, encoding="utf-8")

def _settings_snapshot():
    return {name: value for name, value in vars(config).items()
            if not name.startswith("_") and not isinstance(value, types.ModuleType) and not callable(value)}

def _sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def write_manifest(run_folder):
    files = {}
    for f in sorted(run_folder.rglob("*")):
        if f.is_file() and f.name != "manifest.json":
            files[f.relative_to(run_folder).as_posix()] = _sha256_file(f)
    manifest = {
        "created": datetime.now().isoformat(timespec="seconds"),
        "program_version": config.program_version,
        "algorithm": "sha256",
        "files": files,
    }
    data = json.dumps(manifest, indent=2).encode("utf-8")
    (run_folder / "manifest.json").write_bytes(data)
    return hashlib.sha256(data).hexdigest()

def _new_run_folder():
    base = Path(config.output_folder) / datetime.now().strftime("%Y%m%d-%H%M%S")
    base.parent.mkdir(parents=True, exist_ok=True)
    folder, n = base, 2
    while True:
        try:
            folder.mkdir()
            return folder
        except FileExistsError:
            folder = base.with_name(f"{base.name}-{n}")
            n += 1

def run_once(subject, api_key):
    cache.clean_cache()
    run_folder = _new_run_folder()
    _raw_responses.clear()
    pages = search(subject, api_key)
    print(f"Found {len(pages)} unique pages. Downloading...")
    if not pages:
        save_report(run_folder, subject, [], [], api_key)
        print(f"Report saved in {run_folder}")
        save_text_report(run_folder, subject, [], [], api_key)   
        manifest_hash = write_manifest(run_folder)
        print(f"Manifest SHA-256 (record this in the case file): {manifest_hash}")
        return [], [], run_folder, manifest_hash
    download_all(pages, run_folder / "pages")
    for p in pages:
        analyze_page(p, subject)
    pages = rank(pages)
    hits = cleanup(pages)
    save_report(run_folder, subject, pages, hits, api_key)
    save_text_report(run_folder, subject, pages, hits, api_key)
    print_results(pages, hits, run_folder)
    print(f"Full report: {run_folder / 'report.json'}")
    manifest_hash = write_manifest(run_folder)
    print(f"Manifest SHA-256 (record this in the case file): {manifest_hash}")
    return hits, pages, run_folder, manifest_hash