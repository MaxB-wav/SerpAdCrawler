#SerpAdCrawler window. Run this file (or the .exe built from it) instead of Main.py
#THIS FILE IS AI-GENERATED (Claude Opus 5.5) AND MAY NEED TO BE REVIEWED FOR ACCURACY AND SECURITY
#
#how it fits together:
# - the window runs on the main thread. A search runs on a second (worker) thread so the window never freezes
# - everything the backend print()s during a search is sent to the Progress box instead of a console
# - the worker never touches the window directly (tkinter isn't thread-safe). It puts messages in a queue
#   and the window picks them up every 100 ms in _poll_messages
# - settings are applied by setting the values on the config module, then saved to settings.json

import copy
import csv
import io
import json
import os
import queue
import re
import sys
import threading
import time
import traceback
import webbrowser
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from tkinter import font as tkfont

#when running as an .exe, settings.json, output and cache live next to the .exe; otherwise next to this file
if getattr(sys, "frozen", False):
    APP_FOLDER = Path(sys.executable).resolve().parent
else:
    APP_FOLDER = Path(__file__).resolve().parent
os.chdir(APP_FOLDER)

import config
import basic
from basic import normalize_phone
from serpquery import SearchError, check_api_key, build_queries
from pipeline import run_once
from downloader import domain_of


#settings

SETTINGS_FILE = APP_FOLDER / "settings.json"

#every editable setting in config.py: (section, name in config.py, label shown in the window, kind)
#kinds: bool = checkbox, int / float / text = box, lines = one entry per line (a list)
#keyword_categories has its own editor and isn't listed here. program_version is never editable
SETTINGS = [
    ("Search", "use_phone", "Search by phone number", "bool"),
    ("Search", "use_address", "Search by address", "bool"),
    ("Search", "query_terms", "Words added to every search\n(one per line, blank = none)", "lines"),
    ("Search", "pages_per_query", "Google result pages per query\n(each costs 1 SerpApi credit)", "int"),
    ("Downloads", "download_delay", "Seconds between page downloads", "float"),
    ("Downloads", "google_redirect_wait", "Longest wait on a Google redirect page (seconds)", "float"),
    ("Downloads", "max_page_bytes", "Largest page kept (bytes; 2097152 = 2 MB)", "int"),
    ("Downloads", "max_redirects", "Most redirects followed for one page", "int"),
    ("Downloads", "skip_domains", "Sites never downloaded\n(one per line, e.g. yelp.com)", "lines"),
    ("Scoring", "min_score", "Minimum score for a page to be kept as a hit", "int"),
    ("Scoring", "context_window", "Characters checked for keywords on each side\nof a phone/address match", "int"),
    ("Scoring", "adult_domains", "Known adult sites (one per line). Known adult sites are listed regardless of their score.", "lines"),
    ("Scoring", "adult_domain_weight", "Score added for a page on a known adult site", "int"),
    ("Output and cache", "output_folder", "Output folder", "text"),
    ("Output and cache", "use_cache", "Reuse searches and pages from earlier runs", "bool"),
    ("Output and cache", "cache_folder", "Cache folder", "text"),
    ("Output and cache", "cache_hours", "Hours a cached search or page is reused", "float"),
    ("Output and cache", "cache_max_mb", "Largest the cache folder may get (MB)", "int"),
    ("Debugging", "keep_all_pages", "Keep every downloaded page and the raw search results", "bool"),
]
EDITABLE = [name for _, name, _, _ in SETTINGS] + ["keyword_categories"]
DOMAIN_LISTS = ("skip_domains", "adult_domains")

#config.py's own values, kept before settings.json is applied so "Reset to defaults" can bring them back
DEFAULTS = {name: copy.deepcopy(getattr(config, name)) for name in EDITABLE}

#window-only settings (how the window looks). Saved in settings.json next to the config settings,
#but they aren't part of config.py, so they don't show up in report.json and "Reset to defaults" leaves them alone
UI = {"dark_mode": False}

#dark mode colours
DARK = {
    "bg": "#2b2b2b",          
    "fg": "#ffffff",          
    "field": "#3a3a3a",       
    "button": "#3f3f3f",
    "hover": "#4d4d4d",
    "border": "#555555",
    "select": "#2f5f8f",      
    "disabled_fg": "#8a8a8a",
    "disabled_field": "#333333",
}


#turns "https://www.Example.com/some/page" into "example.com" so domain lists match what downloader expects

def clean_domain(text):
    d = text.strip().lower()
    d = re.sub(r"^[a-z]+://", "", d)
    d = d.split("/")[0].split(":")[0]
    return d.removeprefix("www.")


#checks one keyword category. Returns a list of problems (empty if it's fine)

def category_problems(cat):
    problems = []
    if not str(cat.get("label", "")).strip():
        problems.append("a category has no name")
    if not isinstance(cat.get("weight"), int) or isinstance(cat.get("weight"), bool):
        problems.append(f'"{cat.get("label")}": weight must be a whole number')
    if not isinstance(cat.get("ignore_case"), bool):
        problems.append(f'"{cat.get("label")}": ignore_case must be true or false')
    if not isinstance(cat.get("patterns"), list) or not cat["patterns"]:
        problems.append(f'"{cat.get("label")}": needs at least one pattern')
        return problems
    for p in cat["patterns"]:
        try:
            re.compile(p)
        except re.error as e:
            problems.append(f'"{cat.get("label")}": pattern {p!r} is not valid ({e})')
    return problems


def _is_number(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool)


#loads settings.json (if there is one) onto config. Returns a warning to show, or None

def load_settings():
    if not SETTINGS_FILE.exists():
        return None
    try:
        saved = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
    except (OSError, ValueError) as e:
        return f"settings.json could not be read ({e}). Using the defaults from config.py."
    if not isinstance(saved, dict):
        return "settings.json is not in the expected format. Using the defaults from config.py."
    for name in UI:
        if isinstance(saved.get(name), type(UI[name])):
            UI[name] = saved[name]
    skipped = []
    for name, value in saved.items():
        if name not in EDITABLE:
            continue                                   #old or unknown setting, ignored
        default = DEFAULTS[name]
        #a saved value must be the same type as the default (whole numbers and decimals can stand in for each other)
        same_type = type(value) == type(default) or (_is_number(value) and _is_number(default))
        if name == "keyword_categories" and same_type:
            same_type = all(isinstance(c, dict) and not category_problems(c) for c in value)
        if same_type:
            setattr(config, name, value)
        else:
            skipped.append(name)
    if skipped:
        return "These saved settings were not valid and the defaults were used instead: " + ", ".join(skipped)
    return None


def save_settings():
    data = {name: getattr(config, name) for name in EDITABLE}
    data.update(UI)
    SETTINGS_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")


#CSV batch input
#each row is one subject (one licensee) and gets its own run, folder, report and manifest.
#the first row must be column names. Matching ignores capitals, spaces and punctuation:
#  phone   - every column with "phone" in its name (Phone, Phone 2, Business Phone...), so a row can have several
#  street  - Street, Address, Address 1, Street Address... (one address per row)
#  city    - any column with "city" in its name
#  state   - State or St
#  label   - optional: Name, Licensee, Business Name, License Number... shown in Results and saved in report.json
#other columns are ignored

CSV_STREET = {"street", "streetaddress", "address", "address1", "addressline1", "physicaladdress",
              "businessaddress", "locationaddress"}
CSV_STATE = {"state", "st"}
CSV_LABEL = {"name", "licensee", "licenseename", "businessname", "dba", "subject", "license",
             "licensenumber", "licenseno", "licenseid", "id"}


def _header_key(text):
    return re.sub(r"[^a-z0-9]", "", text.lower())


#reads the whole file as text. Excel saves CSV as UTF-8 or as Windows' own encoding, so both are tried
def _read_csv_text(path):
    raw = Path(path).read_bytes()
    try:
        return raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        return raw.decode("cp1252", errors="replace")


#turns a CSV file into a list of subjects. Returns (subjects, problems, columns_used).
#raises ValueError with a readable message if the file can't be used at all
def read_subjects_csv(path):
    text = _read_csv_text(path)
    try:
        dialect = csv.Sniffer().sniff(text[:4096], delimiters=",;\t")
    except csv.Error:
        dialect = csv.excel
    rows = list(csv.reader(io.StringIO(text, newline=""), dialect))
    if len(rows) < 2:
        raise ValueError("The file needs a row of column names and at least one row of data.")
    headers = [_header_key(h) for h in rows[0]]

    phone_cols = [i for i, h in enumerate(headers) if "phone" in h]
    street_col = next((i for i, h in enumerate(headers) if h in CSV_STREET or "street" in h), None)
    city_col = next((i for i, h in enumerate(headers) if "city" in h), None)
    state_col = next((i for i, h in enumerate(headers) if h in CSV_STATE), None)
    label_cols = [i for i, h in enumerate(headers) if h in CSV_LABEL]
    if not phone_cols and street_col is None:
        raise ValueError("No phone or address columns were found. The first row should have column names "
                         "such as Phone, Street, City, State.\n\nColumns in the file: " + ", ".join(rows[0]))

    used = {"Phone": [rows[0][i] for i in phone_cols],
            "Street": [rows[0][street_col]] if street_col is not None else [],
            "City": [rows[0][city_col]] if city_col is not None else [],
            "State": [rows[0][state_col]] if state_col is not None else [],
            "Label": [rows[0][i] for i in label_cols]}

    def cell(row, i):
        return " ".join(row[i].split()) if i is not None and i < len(row) else ""   #line breaks become spaces

    subjects, problems = [], []
    for line_no, row in enumerate(rows[1:], 2):           #row 1 is the column names (same numbers as Excel)
        if not any(c.strip() for c in row):
            continue                                       #blank line
        label = " - ".join(v for v in (cell(row, i) for i in label_cols) if v)
        name = f"Row {line_no}" + (f" ({label})" if label else "")
        phones = []
        if config.use_phone:
            for i in phone_cols:
                value = cell(row, i)
                if not value:
                    continue
                phone = normalize_phone(value)
                if phone is None:
                    problems.append(f"{name}: {value!r} is not a valid 10-digit US number (left out)")
                elif phone not in phones:
                    phones.append(phone)
        addresses = []
        street, city, state = cell(row, street_col), cell(row, city_col), cell(row, state_col)
        if config.use_address and street:
            if city:
                addresses.append({"street": street, "city": city, "state": state})
            else:
                problems.append(f"{name}: address has no city (left out)")
        if not phones and not addresses:
            problems.append(f"{name}: nothing to search, row skipped")
            continue
        subject = {"phones": phones, "addresses": addresses, "label": label or f"Row {line_no}",
                   "csv_file": Path(path).name, "csv_row": line_no}
        subjects.append(subject)
    return subjects, problems, used


#a Text box with a ttk scrollbar (ScrolledText uses an old-style scrollbar that can't be coloured for dark mode)
def scrolled_text(parent, **options):
    frame = ttk.Frame(parent)
    text = tk.Text(frame, **options)
    bar = ttk.Scrollbar(frame, orient="vertical", command=text.yview)
    text.configure(yscrollcommand=bar.set)
    bar.pack(side="right", fill="y")
    text.pack(side="left", fill="both", expand=True)
    return frame, text


#sends everything print()ed during a search to the window's queue, with the API key hidden

class QueueWriter:
    def __init__(self, messages, secret):
        self.messages = messages
        self.secret = secret

    def write(self, text):
        if text:
            if self.secret:
                text = text.replace(self.secret, "[key]")
            self.messages.put(("log", text))

    def flush(self):
        pass


#the window

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"SerpAdCrawler {config.program_version}")
        self.geometry("1100x750")
        self.minsize(850, 550)

        self.api_key = None                  #only set once SerpApi has accepted it
        self.running = False
        self.messages = queue.Queue()
        self.tree_info = {}                  #results table row id -> ("run", run) or ("hit", hit, run)
        self.new_results = False             #a run finished during this search, so show the Results tab at the end

        self.style = ttk.Style(self)
        self.light_theme = self.style.theme_use()      #Windows' own look ("vista"), used when dark mode is off
        self._light_colours = {}                       #original colours of the plain tk widgets, for switching back

        self._build_key_bar()
        self.tabs = ttk.Notebook(self)
        self.tabs.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        self._build_search_tab()
        self._build_results_tab()
        self._build_settings_tab()

        self._fill_settings_form()
        self._apply_theme()                            #also calls _apply_search_toggles
        self._update_buttons()
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        self.after(100, self._poll_messages)

    #API key bar (top of the window)

    def _build_key_bar(self):
        bar = ttk.Frame(self, padding=8)
        bar.pack(fill="x")
        ttk.Label(bar, text="SerpApi key:").pack(side="left")
        self.key_var = tk.StringVar()
        self.key_entry = ttk.Entry(bar, textvariable=self.key_var, show="•", width=50)
        self.key_entry.pack(side="left", padx=6)
        self.key_entry.bind("<Return>", lambda e: self.check_key())
        self.show_key = tk.BooleanVar()
        ttk.Checkbutton(bar, text="Show", variable=self.show_key,
                        command=lambda: self.key_entry.config(show="" if self.show_key.get() else "•")
                        ).pack(side="left")
        self.check_btn = ttk.Button(bar, text="Check key", command=self.check_key)
        self.check_btn.pack(side="left", padx=6)
        self.key_status = ttk.Label(bar, text="Enter your key and click Check key.")
        self.key_status.pack(side="left", padx=6)
        self.dark_var = tk.BooleanVar(value=UI["dark_mode"])
        ttk.Checkbutton(bar, text="Dark mode", variable=self.dark_var, command=self.toggle_dark_mode
                        ).pack(side="right")
        self.key_var.trace_add("write", lambda *a: self._key_edited())
        self.key_entry.focus_set()

    #editing the key after it was checked means it has to be checked again

    def _key_edited(self):
        if self.api_key is not None and self.key_var.get().strip() != self.api_key:
            self.api_key = None
            self.key_status.config(text="Key changed. Click Check key.")
            self._update_buttons()

    def check_key(self):
        key = self.key_var.get().strip()
        if not key:
            self.key_status.config(text="Enter a key first.")
            return
        self.check_btn.config(state="disabled")
        self.key_status.config(text="Checking...")

        #runs on a separate thread so the window doesn't freeze while SerpApi answers
        def work():
            try:
                left = check_api_key(key)
                self.messages.put(("key_ok", key, left))
            except SearchError as e:
                self.messages.put(("key_bad", str(e)))
        threading.Thread(target=work, daemon=True).start()

    #Search tab

    def _build_search_tab(self):
        tab = ttk.Frame(self.tabs, padding=8)
        self.tabs.add(tab, text="Search")

        inputs = ttk.Frame(tab)
        inputs.pack(fill="x")
        inputs.columnconfigure(0, weight=1)
        inputs.columnconfigure(1, weight=2)

        #phone numbers: a plain text box, one per line
        self.phone_frame = ttk.LabelFrame(inputs, text="Phone numbers (one per line, any format)", padding=6)
        self.phone_frame.grid(row=0, column=0, sticky="nsew", padx=(0, 6))
        self.phone_text = tk.Text(self.phone_frame, height=8, width=24, undo=True)
        self.phone_text.pack(fill="both", expand=True)

        #addresses: street/city/state boxes, an Add button and a list
        self.addr_frame = ttk.LabelFrame(inputs, text="Addresses", padding=6)
        self.addr_frame.grid(row=0, column=1, sticky="nsew")
        row = ttk.Frame(self.addr_frame)
        row.pack(fill="x")
        self.street_var, self.city_var, self.state_var = tk.StringVar(), tk.StringVar(), tk.StringVar()
        self.addr_inputs = []
        for label, var, width in (("Street", self.street_var, 28), ("City", self.city_var, 16),
                                  ("State", self.state_var, 5)):
            ttk.Label(row, text=label).pack(side="left", padx=(0, 2))
            entry = ttk.Entry(row, textvariable=var, width=width)
            entry.pack(side="left", padx=(0, 8))
            entry.bind("<Return>", lambda e: self.add_address())
            self.addr_inputs.append(entry)
        self.add_addr_btn = ttk.Button(row, text="Add", command=self.add_address)
        self.add_addr_btn.pack(side="left")
        self.addr_tree = ttk.Treeview(self.addr_frame, columns=("street", "city", "state"),
                                      show="headings", height=5)
        for col, width in (("street", 260), ("city", 140), ("state", 50)):
            self.addr_tree.heading(col, text=col.title())
            self.addr_tree.column(col, width=width, stretch=(col == "street"))
        self.addr_tree.pack(fill="both", expand=True, pady=(6, 4))
        self.remove_addr_btn = ttk.Button(self.addr_frame, text="Remove selected", command=self.remove_address)
        self.remove_addr_btn.pack(anchor="w")

        #Run / Stop
        buttons = ttk.Frame(tab)
        buttons.pack(fill="x", pady=8)
        self.run_btn = ttk.Button(buttons, text="Run search", command=self.start_run)
        self.run_btn.pack(side="left")
        self.csv_btn = ttk.Button(buttons, text="Run CSV file...", command=self.start_csv_run)
        self.csv_btn.pack(side="left", padx=(6, 0))
        self.stop_btn = ttk.Button(buttons, text="Stop", command=self.stop_run)
        self.stop_btn.pack(side="left", padx=6)
        ttk.Button(buttons, text="Clear inputs", command=self.clear_inputs).pack(side="left", padx=6)
        self.run_status = ttk.Label(buttons, text="")
        self.run_status.pack(side="left", padx=10)

        #progress log
        log_frame = ttk.LabelFrame(tab, text="Progress", padding=4)
        log_frame.pack(fill="both", expand=True)
        frame, self.log = scrolled_text(log_frame, height=12, state="disabled", wrap="word",
                                        font=("Consolas", 9))
        frame.pack(fill="both", expand=True)

    def add_address(self):
        street, city, state = (v.get().strip() for v in (self.street_var, self.city_var, self.state_var))
        if not street:
            return
        if not city:
            messagebox.showwarning("City needed", "A city is required for an address search.", parent=self)
            return
        self.addr_tree.insert("", "end", values=(street, city, state))
        for v in (self.street_var, self.city_var, self.state_var):
            v.set("")
        self.addr_inputs[0].focus_set()

    def remove_address(self):
        for item in self.addr_tree.selection():
            self.addr_tree.delete(item)

    def clear_inputs(self):
        self.phone_text.delete("1.0", "end")
        for item in self.addr_tree.get_children():
            self.addr_tree.delete(item)

    #greys out the phone or address box when that kind of search is turned off in Settings

    def _apply_search_toggles(self):
        if UI["dark_mode"]:
            on, off = DARK["field"], DARK["disabled_field"]
        else:
            on, off = "white", "#e8e8e8"
        self.phone_text.config(state="normal" if config.use_phone else "disabled",
                               background=on if config.use_phone else off)
        state = "normal" if config.use_address else "disabled"
        for w in self.addr_inputs + [self.add_addr_btn, self.remove_addr_btn]:
            w.config(state=state)
        self.phone_frame.config(text="Phone numbers (one per line, any format)" +
                                ("" if config.use_phone else " - turned off in Settings"))
        self.addr_frame.config(text="Addresses" + ("" if config.use_address else " - turned off in Settings"))

    #reads the inputs into the same subject dictionary basic.ask_subject() made. Returns None if not usable

    def _collect_subject(self):
        phones, bad = [], []
        if config.use_phone:
            for line in self.phone_text.get("1.0", "end").splitlines():
                if not line.strip():
                    continue
                phone = normalize_phone(line)
                if phone is None:
                    bad.append(line.strip())
                elif phone not in phones:
                    phones.append(phone)
        if bad:
            messagebox.showwarning("Check the phone numbers",
                                   "These are not valid 10-digit US numbers:\n\n" + "\n".join(bad), parent=self)
            return None
        addresses = []
        if config.use_address:
            for item in self.addr_tree.get_children():
                street, city, state = self.addr_tree.item(item, "values")
                addresses.append({"street": street, "city": city, "state": state})
        if not phones and not addresses:
            messagebox.showinfo("Nothing to search", "Enter at least one phone number or address.", parent=self)
            return None
        return {"phones": phones, "addresses": addresses}

    def start_run(self):
        if self.running or self.api_key is None:
            return
        subject = self._collect_subject()
        if subject is None:
            return
        self._start_worker([subject])

    #picks a CSV file, shows what's in it and how many credits it may use, then runs every row
    def start_csv_run(self):
        if self.running or self.api_key is None:
            return
        path = filedialog.askopenfilename(parent=self, title="Choose a CSV file (one subject per row)",
                                          filetypes=[("CSV files", "*.csv"), ("All files", "*.*")])
        if not path:
            return
        try:
            subjects, problems, used = read_subjects_csv(path)
        except (OSError, ValueError) as e:
            messagebox.showerror("Can't use this file", str(e), parent=self)
            return
        if not subjects:
            messagebox.showwarning("Nothing to search", "No row in the file had a usable phone number or "
                                   "address.\n\n" + "\n".join(problems[:15]), parent=self)
            return
        queries = sum(len(build_queries(s)) for s in subjects)
        credits = queries * config.pages_per_query
        columns = "\n".join(f"  {k}: {', '.join(v)}" for k, v in used.items() if v)
        text = (f"{len(subjects)} subjects found in {Path(path).name}. Each one is searched separately "
                f"and gets its own run folder.\n\nColumns used:\n{columns}\n\n"
                f"This uses up to {credits} SerpApi credits ({queries} searches x {config.pages_per_query} "
                f"page(s)); searches still in the cache are free.")
        if problems:
            shown = problems[:10] + ([f"...and {len(problems) - 10} more"] if len(problems) > 10 else [])
            text += f"\n\n{len(problems)} problem(s):\n" + "\n".join(shown)
        if not messagebox.askyesno("Run CSV file", text + "\n\nRun it now?", parent=self):
            return
        if problems:
            self._log(f"\nProblems in {Path(path).name}:\n" + "\n".join(problems) + "\n")
        self._start_worker(subjects)

    def _start_worker(self, subjects):
        basic.stop_event.clear()
        self.running = True
        self.new_results = False
        self.run_status.config(text="Running...")
        self._update_buttons()
        self._log("\n" + "=" * 70 + "\n")
        threading.Thread(target=self._run_worker, args=(subjects,), daemon=True).start()

    def stop_run(self):
        if self.running:
            basic.stop_event.set()
            self.run_status.config(text="Stopping after the current step...")
            self.stop_btn.config(state="disabled")

    #runs on the worker thread: runs every subject and reports back through the queue

    def _run_worker(self, subjects):
        old_stdout = sys.stdout
        sys.stdout = QueueWriter(self.messages, self.api_key)
        failed = []
        try:
            for n, subject in enumerate(subjects, 1):
                basic.check_stop()
                if len(subjects) > 1:
                    self.messages.put(("status", f"Running subject {n} of {len(subjects)}..."))
                    print(f"\n=== Subject {n} of {len(subjects)}: {subject.get('label', '')} ===")
                try:
                    hits, pages, run_folder, manifest_hash = run_once(subject, self.api_key)
                except SearchError as e:
                    print(f"Search failed: {e}")
                    failed.append(subject.get("label", f"subject {n}"))
                    continue
                self.messages.put(("result", subject, hits, pages, run_folder, manifest_hash))
            if len(subjects) > 1:
                print(f"\nCSV batch finished: {len(subjects) - len(failed)} of {len(subjects)} subjects searched.")
                if failed:
                    print("Search failed for: " + "; ".join(failed))
        except basic.StoppedByUser:
            print("\nStopped. The unfinished run's folder has no report.json or manifest.")
        except Exception:
            print("\nUnexpected error. Please send this to whoever maintains the program:\n")
            print(traceback.format_exc())
        finally:
            sys.stdout = old_stdout
            self.messages.put(("finished",))

    #picks up messages from the worker threads (runs on the main thread every 100 ms)

    def _poll_messages(self):
        try:
            while True:
                msg = self.messages.get_nowait()
                kind = msg[0]
                if kind == "log":
                    self._log(msg[1])
                elif kind == "result":
                    self._add_run(*msg[1:])
                elif kind == "status":
                    if not basic.stop_event.is_set():
                        self.run_status.config(text=msg[1])
                elif kind == "finished":
                    self.running = False
                    self.run_status.config(text="Stopped." if basic.stop_event.is_set() else "Done.")
                    self._update_buttons()
                    if self.new_results:
                        self.tabs.select(1)
                elif kind == "key_ok":
                    _, key, left = msg
                    if key == self.key_var.get().strip():
                        self.api_key = key
                        self.key_status.config(text=f"Key OK. {left} searches left.")
                    self.check_btn.config(state="normal")
                    self._update_buttons()
                elif kind == "key_bad":
                    self.key_status.config(text=msg[1])
                    self.check_btn.config(state="normal")
        except queue.Empty:
            pass
        self.after(100, self._poll_messages)

    def _log(self, text):
        self.log.config(state="normal")
        self.log.insert("end", text)
        self.log.see("end")
        self.log.config(state="disabled")

    #turns buttons on/off depending on whether the key is checked and a search is running

    def _update_buttons(self):
        can_run = self.api_key is not None and not self.running
        self.run_btn.config(state="normal" if can_run else "disabled")
        self.csv_btn.config(state="normal" if can_run else "disabled")
        self.stop_btn.config(state="normal" if self.running else "disabled")
        self.save_btn.config(state="disabled" if self.running else "normal")
        self.reset_btn.config(state="disabled" if self.running else "normal")
        if self.api_key is None and not self.running:
            self.run_status.config(text="Check your API key to start.")
        elif self.run_status.cget("text") == "Check your API key to start.":
            self.run_status.config(text="")

    #Results tab: one row per run, with its hits underneath

    def _build_results_tab(self):
        tab = ttk.Frame(self.tabs, padding=8)
        self.tabs.add(tab, text="Results")
        panes = ttk.PanedWindow(tab, orient="vertical")
        panes.pack(fill="both", expand=True)

        top = ttk.Frame(panes)
        cols = ("score", "keywords", "matched", "url")
        self.results_tree = ttk.Treeview(top, columns=cols, show="tree headings")
        self.results_tree.heading("#0", text="Run / site")
        self.results_tree.column("#0", width=260, stretch=False)
        for col, title, width, stretch in (("score", "Score", 60, False), ("keywords", "Keywords found", 320, True),
                                           ("matched", "Matched", 200, False), ("url", "URL", 300, True)):
            self.results_tree.heading(col, text=title)
            self.results_tree.column(col, width=width, stretch=stretch)
        scroll = ttk.Scrollbar(top, orient="vertical", command=self.results_tree.yview)
        self.results_tree.configure(yscrollcommand=scroll.set)
        self.results_tree.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        self.results_tree.bind("<<TreeviewSelect>>", lambda e: self._show_details())
        self.results_tree.bind("<Double-1>", lambda e: self.open_in_browser())
        self.results_tree.tag_configure("flagged", foreground="#d97a00")
        panes.add(top, weight=3)

        bottom = ttk.Frame(panes)
        buttons = ttk.Frame(bottom)
        buttons.pack(fill="x", pady=(6, 4))
        for text, command in (("Open page in browser", self.open_in_browser),
                              ("Open saved copy", self.open_saved_copy),
                              ("Open run folder", self.open_run_folder),
                              ("Copy manifest hash", self.copy_manifest_hash),
                              ("Add site to skip list", lambda: self.add_site_to("skip_domains")),
                              ("Add site to adult list", lambda: self.add_site_to("adult_domains"))):
            ttk.Button(buttons, text=text, command=command).pack(side="left", padx=(0, 6))
        frame, self.details = scrolled_text(bottom, height=10, state="disabled", wrap="word")
        frame.pack(fill="both", expand=True)
        panes.add(bottom, weight=2)

    #adds one finished run (and its hits) to the results table and switches to it

    def _add_run(self, subject, hits, pages, run_folder, manifest_hash):
        failed = sum(1 for p in pages if p.get("error"))
        flagged = sum(1 for h in hits if h.get("flag"))
        parts = [f"{len(subject['phones'])} phone(s)"] if subject["phones"] else []
        if subject["addresses"]:
            parts.append(f"{len(subject['addresses'])} address(es)")
        run = {"folder": Path(run_folder), "manifest": manifest_hash, "subject": subject, "pages": len(pages),
               "failed": failed, "hits": len(hits) - flagged, "flagged": flagged, "min_score": config.min_score}
        name = Path(run_folder).name
        if subject.get("label"):
            name = f"{subject['label']}  ({name})"
        summary = f"{run['hits']} hits"
        if flagged:
            summary += f" + {flagged} flagged adult site(s)"
        summary += f" from {len(pages)} pages ({failed} failed/skipped)"
        run_id = self.results_tree.insert("", "end", text=name, open=True,
                                          values=("", summary, ", ".join(parts), ""))
        self.tree_info[run_id] = ("run", run)
        for h in hits:
            if h.get("flag"):
                #known adult site listed regardless of score: the flag explains why it's here
                values = ("FLAG", h["flag"], ", ".join(h["matched"]) or "-", h["url"])
                tags = ("flagged",)
            else:
                keywords = "; ".join(f"{k['label']}: {', '.join(k['terms'])}" for k in h["keywords"])
                values = (h["score"], keywords, ", ".join(h["matched"]), h["url"])
                tags = ()
            item = self.results_tree.insert(run_id, "end", text=domain_of(h.get("final_url") or h["url"]),
                                            values=values, tags=tags)
            self.tree_info[item] = ("hit", h, run)
        self.results_tree.selection_set(run_id)
        self.results_tree.see(run_id)
        self.new_results = True                        #the Results tab opens when the whole search is done

    #the run or hit picked in the results table, or None

    def _selected(self):
        sel = self.results_tree.selection()
        return self.tree_info.get(sel[0]) if sel else None

    def _show_details(self):
        info = self._selected()
        lines = []
        if info and info[0] == "run":
            run = info[1]
            lines += [f"Run folder: {run['folder'].resolve()}",
                      f"Manifest SHA-256 (record this in the case file): {run['manifest']}",
                      f"{run['pages']} pages, {run['failed']} skipped/failed, {run['hits']} hits "
                      f"(score >= {run['min_score']}), {run.get('flagged', 0)} flagged known adult site page(s)", ""]
            if run["subject"].get("csv_file"):
                lines.append(f"From:    {run['subject']['csv_file']}, row {run['subject']['csv_row']}")
            if run["subject"].get("label"):
                lines.append(f"Subject: {run['subject']['label']}")
            for p in run["subject"]["phones"]:
                lines.append(f"Phone:   ({p[:3]}) {p[3:6]}-{p[6:]}")
            for a in run["subject"]["addresses"]:
                lines.append(f"Address: {a['street']}, {a['city']} {a['state']}".rstrip())
            if not run["hits"] and run["failed"]:
                lines += ["", f"NOTE: no hits, but {run['failed']} pages could not be read. This does not mean "
                              "nothing was found; check the skipped/failed pages in report.json."]
        elif info:
            h = info[1]
            if h.get("flag"):
                lines += [f"FLAGGED:  {h['flag']}",
                          "          Listed because the site is on the known adult sites list, not because",
                          "          of its score. Check the page yourself (it may be behind an age check).", ""]
            lines += [f"Title:    {h.get('title', '')}", f"URL:      {h['url']}"]
            if h.get("final_url") and h["final_url"] != h["url"]:
                lines.append(f"Ended at: {h['final_url']}")
            lines += [f"Found by: " + ", ".join(f"{f['kind']} {f['target']}" for f in h.get("found_by", [])),
                      f"Score:    {h['score']}  ({h['keyword_hits']} keyword hits)",
                      f"Matched:  {', '.join(h['matched'])}"]
            for k in h["keywords"]:
                lines.append(f"  {k['label']} (+{k['weight']}): {', '.join(k['terms'])}")
            lines.append(f"Saved:    {h.get('fetched_at') or ''}{' (from cache)' if h.get('from_cache') else ''}"
                         f"{' (cut off at max page size)' if h.get('truncated') else ''}")
            if h.get("error"):
                lines.append(f"Problem:  {h['error']}")
            if h.get("excerpt"):
                lines += ["", "Text around the match:", h["excerpt"]]
            if h.get("flag") and h.get("snippet"):
                lines += ["", "Google's snippet:", h["snippet"]]
        self.details.config(state="normal")
        self.details.delete("1.0", "end")
        self.details.insert("1.0", "\n".join(lines))
        self.details.config(state="disabled")

    def _selected_hit(self):
        info = self._selected()
        if not info or info[0] != "hit":
            messagebox.showinfo("Pick a hit", "Select one of the hit pages (under a run) first.", parent=self)
            return None
        return info[1]

    def open_in_browser(self):
        info = self._selected()
        if info and info[0] == "hit":
            webbrowser.open(info[1].get("final_url") or info[1]["url"])

    def open_saved_copy(self):
        h = self._selected_hit()
        if h is None:
            return
        if not h.get("file") or not Path(h["file"]).exists():
            messagebox.showinfo("No saved copy", "There is no saved copy of this page (it may not have "
                                "downloaded; see Problem in the details below).", parent=self)
            return
        os.startfile(Path(h["file"]).resolve())

    def open_run_folder(self):
        info = self._selected()
        if info:
            run = info[1] if info[0] == "run" else info[2]
            os.startfile(run["folder"].resolve())

    def copy_manifest_hash(self):
        info = self._selected()
        if info:
            run = info[1] if info[0] == "run" else info[2]
            self.clipboard_clear()
            self.clipboard_append(run["manifest"])
            self.run_status.config(text="Manifest hash copied.")

    #adds the selected hit's site to skip_domains or adult_domains and saves settings

    def add_site_to(self, list_name):
        h = self._selected_hit()
        if h is None:
            return
        if self.running:
            messagebox.showinfo("Search running", "Settings can't change while a search is running.", parent=self)
            return
        site = domain_of(h.get("final_url") or h["url"])
        entries = getattr(config, list_name)
        if site in entries:
            messagebox.showinfo("Already listed", f"{site} is already on that list.", parent=self)
            return
        what = "never be downloaded" if list_name == "skip_domains" else \
               f"get +{config.adult_domain_weight} as a known adult site"
        if not messagebox.askyesno("Add site", f"Add {site}?\n\nIn future searches it will {what}.", parent=self):
            return
        setattr(config, list_name, entries + [site])
        save_settings()
        self._fill_settings_form()

    #Settings tab

    def _build_settings_tab(self):
        tab = ttk.Frame(self.tabs)
        self.tabs.add(tab, text="Settings")

        #Save / Undo / Reset stay at the bottom while the form above scrolls
        bar = ttk.Frame(tab, padding=8)
        bar.pack(side="bottom", fill="x")
        self.save_btn = ttk.Button(bar, text="Save settings", command=self.save_settings_form)
        self.save_btn.pack(side="left")
        ttk.Button(bar, text="Undo changes", command=self._fill_settings_form).pack(side="left", padx=6)
        self.reset_btn = ttk.Button(bar, text="Reset to defaults", command=self.reset_settings)
        self.reset_btn.pack(side="left")
        self.settings_status = ttk.Label(bar, text=f"Saved in {SETTINGS_FILE}")
        self.settings_status.pack(side="left", padx=10)

        #a scrollable area: a Canvas with a Frame inside it, and a scrollbar
        canvas = tk.Canvas(tab, highlightthickness=0)
        scroll = ttk.Scrollbar(tab, orient="vertical", command=canvas.yview)
        form = ttk.Frame(canvas, padding=8)
        form.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=form, anchor="nw")
        canvas.configure(yscrollcommand=scroll.set)
        canvas.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        #mouse wheel scrolls the form only while the mouse is over it
        wheel = lambda e: canvas.yview_scroll(int(-e.delta / 120), "units")
        canvas.bind("<Enter>", lambda e: canvas.bind_all("<MouseWheel>", wheel))
        canvas.bind("<Leave>", lambda e: canvas.unbind_all("<MouseWheel>"))

        #one box per section, one row per setting, built from the SETTINGS list
        self.setting_widgets = {}
        sections = {}
        for section, name, label, kind in SETTINGS:
            if section not in sections:
                frame = ttk.LabelFrame(form, text=section, padding=8)
                frame.pack(fill="x", pady=(0, 8))
                sections[section] = frame
            frame = sections[section]
            r = len(frame.grid_slaves(column=0))
            if kind == "bool":
                var = tk.BooleanVar()
                ttk.Checkbutton(frame, text=label, variable=var).grid(row=r, column=0, columnspan=2,
                                                                      sticky="w", pady=2)
                self.setting_widgets[name] = (kind, var)
                continue
            ttk.Label(frame, text=label).grid(row=r, column=0, sticky="nw", pady=2, padx=(0, 12))
            if kind == "lines":
                widget = tk.Text(frame, height=4, width=40)
                widget.grid(row=r, column=1, sticky="w", pady=2)
                self.setting_widgets[name] = (kind, widget)
            else:
                var = tk.StringVar()
                ttk.Entry(frame, textvariable=var, width=40 if kind == "text" else 12).grid(
                    row=r, column=1, sticky="w", pady=2)
                self.setting_widgets[name] = (kind, var)

        self._build_category_editor(form)

    #keyword categories: a list on the left, the selected category's details on the right

    def _build_category_editor(self, parent):
        box = ttk.LabelFrame(parent, text="Keyword categories (each adds its weight once if any pattern "
                                          "is found near the phone/address)", padding=8)
        box.pack(fill="x", pady=(0, 8))
        self.cat_tree = ttk.Treeview(box, columns=("weight", "case"), show="tree headings", height=7)
        self.cat_tree.heading("#0", text="Category")
        self.cat_tree.heading("weight", text="Weight")
        self.cat_tree.heading("case", text="Ignore case")
        self.cat_tree.column("#0", width=230)
        self.cat_tree.column("weight", width=60, anchor="center")
        self.cat_tree.column("case", width=80, anchor="center")
        self.cat_tree.grid(row=0, column=0, rowspan=6, sticky="ns", padx=(0, 12))
        self.cat_tree.bind("<<TreeviewSelect>>", lambda e: self._show_category())

        self.cat_label, self.cat_weight, self.cat_case = tk.StringVar(), tk.StringVar(), tk.BooleanVar()
        ttk.Label(box, text="Name").grid(row=0, column=1, sticky="w")
        ttk.Entry(box, textvariable=self.cat_label, width=36).grid(row=0, column=2, sticky="w")
        ttk.Label(box, text="Weight").grid(row=1, column=1, sticky="w")
        ttk.Entry(box, textvariable=self.cat_weight, width=8).grid(row=1, column=2, sticky="w")
        ttk.Checkbutton(box, text="Ignore capitals", variable=self.cat_case).grid(row=2, column=2, sticky="w")
        ttk.Label(box, text="Patterns\n(regex, one per line)").grid(row=3, column=1, sticky="nw")
        self.cat_patterns = tk.Text(box, height=5, width=60, font=("Consolas", 9))
        self.cat_patterns.grid(row=3, column=2, sticky="w")
        buttons = ttk.Frame(box)
        buttons.grid(row=4, column=2, sticky="w", pady=6)
        ttk.Button(buttons, text="Update selected", command=self.update_category).pack(side="left")
        ttk.Button(buttons, text="Add as new", command=lambda: self.update_category(new=True)).pack(
            side="left", padx=6)
        ttk.Button(buttons, text="Delete selected", command=self.delete_category).pack(side="left")
        ttk.Label(box, text="Category changes take effect when you click Save settings.",
                  foreground="gray").grid(row=5, column=2, sticky="w")

    def _refresh_category_list(self):
        self.cat_tree.delete(*self.cat_tree.get_children())
        for i, cat in enumerate(self.categories):
            self.cat_tree.insert("", "end", iid=str(i), text=cat["label"],
                                 values=(cat["weight"], "yes" if cat["ignore_case"] else "no"))

    def _show_category(self):
        sel = self.cat_tree.selection()
        if not sel:
            return
        cat = self.categories[int(sel[0])]
        self.cat_label.set(cat["label"])
        self.cat_weight.set(str(cat["weight"]))
        self.cat_case.set(cat["ignore_case"])
        self.cat_patterns.delete("1.0", "end")
        self.cat_patterns.insert("1.0", "\n".join(cat["patterns"]))

    #replaces the selected category with what's in the boxes (or adds it as a new one)

    def update_category(self, new=False):
        sel = self.cat_tree.selection()
        if not new and not sel:
            messagebox.showinfo("Pick a category", "Select a category to update, or use Add as new.", parent=self)
            return
        try:
            weight = int(self.cat_weight.get().strip())
        except ValueError:
            weight = None
        cat = {"label": self.cat_label.get().strip(), "weight": weight, "ignore_case": self.cat_case.get(),
               "patterns": [p for p in self.cat_patterns.get("1.0", "end").splitlines() if p.strip()]}
        problems = category_problems(cat)
        if problems:
            messagebox.showwarning("Check the category", "\n".join(problems), parent=self)
            return
        if new:
            self.categories.append(cat)
        else:
            self.categories[int(sel[0])] = cat
        self._refresh_category_list()
        index = len(self.categories) - 1 if new else int(sel[0])
        self.cat_tree.selection_set(str(index))
        self.settings_status.config(text="Unsaved changes. Click Save settings.")

    def delete_category(self):
        sel = self.cat_tree.selection()
        if not sel:
            return
        cat = self.categories[int(sel[0])]
        if messagebox.askyesno("Delete category", f'Delete "{cat["label"]}"?', parent=self):
            del self.categories[int(sel[0])]
            self._refresh_category_list()
            self.settings_status.config(text="Unsaved changes. Click Save settings.")

    #puts the current config values into the form (also used by Undo changes)

    def _fill_settings_form(self):
        for name, (kind, widget) in self.setting_widgets.items():
            value = getattr(config, name)
            if kind == "bool":
                widget.set(bool(value))
            elif kind == "lines":
                widget.delete("1.0", "end")
                widget.insert("1.0", "\n".join(value))
            else:
                widget.set(str(value))
        self.categories = copy.deepcopy(config.keyword_categories)
        self._refresh_category_list()
        for var in (self.cat_label, self.cat_weight):
            var.set("")
        self.cat_patterns.delete("1.0", "end")
        self.settings_status.config(text=f"Saved in {SETTINGS_FILE}")

    #reads and checks the whole form. Returns {name: value}, or None after showing what's wrong

    def _read_settings_form(self):
        values, problems = {}, []
        for section, name, label, kind in SETTINGS:
            _, widget = self.setting_widgets[name]
            label = " ".join(label.split())
            if kind == "bool":
                values[name] = widget.get()
            elif kind == "lines":
                lines = [l.strip() for l in widget.get("1.0", "end").splitlines() if l.strip()]
                if name in DOMAIN_LISTS:
                    lines = list(dict.fromkeys(clean_domain(l) for l in lines))
                values[name] = lines
            elif kind == "text":
                values[name] = widget.get().strip()
                if not values[name]:
                    problems.append(f"{label}: can't be empty")
            else:
                number_type = int if kind == "int" else float
                try:
                    values[name] = number_type(widget.get().strip())
                    if values[name] < 0:
                        problems.append(f"{label}: can't be negative")
                except ValueError:
                    problems.append(f"{label}: must be a {'whole ' if kind == 'int' else ''}number")
        if values.get("pages_per_query") == 0:
            problems.append("Google result pages per query: must be at least 1")
        if not (values.get("use_phone") or values.get("use_address")):
            problems.append("Turn on at least one of: Search by phone number / Search by address")
        if problems:
            messagebox.showwarning("Check the settings", "\n".join(problems), parent=self)
            return None
        values["keyword_categories"] = copy.deepcopy(self.categories)
        return values

    def save_settings_form(self):
        if self.running:
            return
        values = self._read_settings_form()
        if values is None:
            return
        for name, value in values.items():
            setattr(config, name, value)
        try:
            save_settings()
        except OSError as e:
            messagebox.showerror("Not saved", f"The settings are in use now but could not be saved to "
                                              f"{SETTINGS_FILE}:\n{e}", parent=self)
            return
        self._fill_settings_form()                     #shows the cleaned-up values (e.g. domain lists)
        self._apply_search_toggles()
        self.settings_status.config(text="Saved.")

    def reset_settings(self):
        if self.running:
            return
        if not messagebox.askyesno("Reset to defaults", "Put every setting back to the values in config.py? "
                                   "This includes the skip/adult site lists and keyword categories.",
                                   parent=self):
            return
        for name, value in DEFAULTS.items():
            setattr(config, name, copy.deepcopy(value))
        save_settings()
        self._fill_settings_form()
        self._apply_search_toggles()
        self.settings_status.config(text="Reset to defaults and saved.")

    #dark mode
    #ttk widgets (buttons, tabs, tables, entries...) are coloured through a ttk "theme". Windows' own theme
    #ignores colour changes, so dark mode switches to the built-in "clam" theme and colours that.
    #plain tk widgets (the Text boxes and the Settings canvas) aren't part of a theme and are coloured one by one

    def toggle_dark_mode(self):
        UI["dark_mode"] = self.dark_var.get()
        self._apply_theme()
        try:
            save_settings()
        except OSError:
            pass                                       #not worth bothering the user; it's only the look

    def _apply_theme(self):
        dark = UI["dark_mode"]
        if dark:
            self._use_dark_theme()
        else:
            self.style.theme_use(self.light_theme)
        #table rows are a fixed height in both themes, which clips text on scaled (125%/150%) screens,
        #so size them to the font. Done after theme_use because each theme keeps its own settings
        row_height = tkfont.nametofont("TkDefaultFont").metrics("linespace") + 6
        self.style.configure("Treeview", rowheight=row_height)
        for w in self._all_widgets(self):
            if isinstance(w, (tk.Text, tk.Canvas, tk.Tk)):
                self._colour_plain_widget(w, dark)
        self._apply_search_toggles()
        #the title bar only exists once the window is on screen, so this waits a moment
        self.after(50, lambda: self._dark_title_bar(dark))

    def _all_widgets(self, parent):
        yield parent
        for child in parent.winfo_children():
            yield from self._all_widgets(child)

    def _colour_plain_widget(self, w, dark):
        if isinstance(w, tk.Text):
            options = {"background": DARK["field"], "foreground": DARK["fg"], "insertbackground": DARK["fg"],
                       "selectbackground": DARK["select"], "selectforeground": DARK["fg"]}
        else:                                          #Canvas or the main window
            options = {"background": DARK["bg"]}
        if w not in self._light_colours:               #remember the original colours the first time
            self._light_colours[w] = {k: w.cget(k) for k in options}
        w.configure(**(options if dark else self._light_colours[w]))

    def _use_dark_theme(self):
        s, c = self.style, DARK
        s.theme_use("clam")
        #"." is the default for every ttk widget; the lines after it fix the ones that need more
        s.configure(".", background=c["bg"], foreground=c["fg"], fieldbackground=c["field"],
                    bordercolor=c["border"], lightcolor=c["bg"], darkcolor=c["bg"], troughcolor=c["bg"],
                    selectbackground=c["select"], selectforeground=c["fg"], insertcolor=c["fg"],
                    focuscolor=c["border"])
        s.map(".", foreground=[("disabled", c["disabled_fg"])])
        s.configure("TButton", background=c["button"], lightcolor=c["button"], darkcolor=c["button"])
        s.map("TButton", background=[("disabled", c["bg"]), ("pressed", c["select"]), ("active", c["hover"])],
              foreground=[("disabled", c["disabled_fg"])])
        s.configure("TEntry", fieldbackground=c["field"], foreground=c["fg"], insertcolor=c["fg"])
        s.map("TEntry", fieldbackground=[("disabled", c["disabled_field"])],
              foreground=[("disabled", c["disabled_fg"])])
        s.configure("TCheckbutton", indicatorbackground=c["field"], indicatorforeground=c["fg"])
        s.map("TCheckbutton", background=[("active", c["bg"])],
              indicatorbackground=[("disabled", c["disabled_field"]), ("pressed", c["hover"])])
        s.configure("TNotebook", background=c["bg"], bordercolor=c["border"])
        s.configure("TNotebook.Tab", background=c["button"], foreground=c["fg"], padding=(10, 4))
        s.map("TNotebook.Tab", background=[("selected", c["bg"]), ("active", c["hover"])])
        s.configure("TLabelframe", background=c["bg"], bordercolor=c["border"])
        s.configure("TLabelframe.Label", background=c["bg"], foreground=c["fg"])
        s.configure("Treeview", background=c["field"], fieldbackground=c["field"], foreground=c["fg"])
        s.map("Treeview", background=[("selected", c["select"])], foreground=[("selected", c["fg"])])
        s.configure("Treeview.Heading", background=c["button"], foreground=c["fg"], bordercolor=c["border"])
        s.map("Treeview.Heading", background=[("active", c["hover"])])
        s.configure("TScrollbar", background=c["button"], troughcolor=c["bg"], arrowcolor=c["fg"],
                    bordercolor=c["border"])
        s.map("TScrollbar", background=[("active", c["hover"])])
        s.configure("TPanedwindow", background=c["border"])

    #Windows 10/11 can draw the title bar dark too. Does nothing on older Windows or other systems
    def _dark_title_bar(self, dark):
        try:
            import ctypes
            self.update_idletasks()
            hwnd = ctypes.windll.user32.GetParent(self.winfo_id())
            value = ctypes.c_int(1 if dark else 0)
            for attribute in (20, 19):                 #20 = Windows 11 / newer 10, 19 = older Windows 10
                if ctypes.windll.dwmapi.DwmSetWindowAttribute(hwnd, attribute, ctypes.byref(value),
                                                             ctypes.sizeof(value)) == 0:
                    break
            #the title bar only redraws when the window changes size, so nudge it
            if self.winfo_ismapped() and self.state() == "normal":
                w, h = self.winfo_width(), self.winfo_height()
                self.geometry(f"{w + 1}x{h}")
                self.update_idletasks()
                self.geometry(f"{w}x{h}")
        except Exception:
            pass

    #closing the window

    def on_close(self):
        if self.running:
            if not messagebox.askyesno("Search running", "A search is still running. Stop it and close?",
                                       parent=self):
                return
            basic.stop_event.set()
        self.destroy()


def main():
    #sharp text on high-resolution Windows screens (otherwise Windows stretches the window and it looks blurry)
    try:
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass
    warning = load_settings()
    app = App()
    if warning:
        messagebox.showwarning("Settings", warning, parent=app)
    app.mainloop()


if __name__ == "__main__":
    main()
