import re
from bs4 import BeautifulSoup
from pathlib import Path
import config
from downloader import domain_of
from basic import normalize_phone

#parsing functions follow

def page_text(file_path):
    soup = BeautifulSoup(Path(file_path).read_bytes(), "html.parser")

    #"Call us" buttons:
    for link in soup.select('a[href^="tel:"]'):
        link.append(" " + link["href"][4:] + " ")
    data_phones = []
    for script in soup.select('script[type="application/ld+json"]'):
        data_phones += re.findall(r'"telephone"\s*:\s*"([^"]+)"', script.get_text())

    for tag in soup(["script", "style", "noscript", "template"]):
        tag.decompose()
    text = soup.get_text("\n")
    if data_phones:
        text += "\nPhone (from page data): " + ", ".join(data_phones)
    text = re.sub(r"[ \t\xa0]+", " ", text)
    return re.sub(r"\n\s*\n+", "\n", text).strip()

PHONE_RE = re.compile(r"(?<![\dA-Za-z])(?:\+?1[ .-]?)?\(?\d{3}\)?[ .-]*\d{3}[ .-]*\d{4}(?![\dA-Za-z])")

_ADDRESS_ABBREV = {"street": "st", "avenue": "ave", "boulevard": "blvd", "drive": "dr", "road": "rd",
                   "lane": "ln", "court": "ct", "highway": "hwy", "parkway": "pkwy", "place": "pl",
                   "north": "n", "south": "s", "east": "e", "west": "w", "expressway": "expy", "freeway": "fwy", 
                   "circle": "cir", "terrace": "ter", "trail": "trl", "square": "sq",}

def _norm_address(s):
    s = (s or "").lower()
    s = re.sub(r"\b(?:suite|ste|apt|unit|bldg|rm)\b\.?\s*[\w-]*|#\s*[\w-]+", " ", s)
    s = re.sub(r"\b(" + "|".join(_ADDRESS_ABBREV) + r")\b", lambda m: _ADDRESS_ABBREV[m.group(1)], s)
    return re.sub(r"[^a-z0-9]+", " ", s).strip()

def find_subject(text, subject):
    matches = []
    for m in PHONE_RE.finditer(text):
        phone = normalize_phone(m.group())
        if phone in subject["phones"]:
            start = max(0, m.start() - config.context_window)
            matches.append({"kind": "phone", "target": phone, "context": text[start:m.end() + config.context_window]})

    if subject["addresses"]:
        norm_text = f" {_norm_address(text)} "
        for a in subject["addresses"]:
            street, city = _norm_address(a["street"]), _norm_address(a["city"])
            for m in re.finditer(rf" {re.escape(street)} ", norm_text):
                #requires city to be nearby to street
                if f" {city} " in norm_text[max(0, m.start() - 100):m.end() + 160]:
                    start = max(0, m.start() - config.context_window)
                    target = f'{a["street"]}, {a["city"]} {a["state"]}'.strip()
                    matches.append({"kind": "address", "target": target,
                                    "context": norm_text[start:m.end() + config.context_window]})
    return matches

def score_text(text):
    _COMPILED_CATEGORIES = [
    {**cat, "compiled": [re.compile(p, re.I if cat["ignore_case"] else 0) for p in cat["patterns"]]}
    for cat in config.keyword_categories]
    score, hits, found = 0, 0, []
    for cat in _COMPILED_CATEGORIES:
        terms = [m.group() for p in cat["compiled"] for m in p.finditer(text)]
        if terms:
            score += cat["weight"]
            hits += len(terms)
            found.append({"label": cat["label"], "weight": cat["weight"],
                          "terms": sorted({t.lower() for t in terms})})
    return score, hits, found

def adult_site(url):
    dom = domain_of(url)
    for d in config.adult_domains:
        d = d.lower().removeprefix("www.")
        if dom == d or dom.endswith("." + d):
            return d
    return None

#it is midnight and I am very tired ;-; 

def analyze_page(page, subject):
    page.update(matched=[], score=0, keyword_hits=0, keywords=[], excerpt="", flag=None)
    page["adult_site"] = adult_site(page["url"]) or adult_site(page.get("final_url") or "")
    if not page.get("file"):
        return page
    try:
        text = page_text(page["file"])
    except Exception as e:
        page["error"] = f"could not read page ({type(e).__name__})"
        return page
    matches = find_subject(text, subject)
    where = ""
    if not matches:
        #search the raw source as a last resort and label
        source = Path(page["file"]).read_bytes().decode("utf-8", errors="replace")
        matches = find_subject(source, subject)
        where = " (page source only)"
    if not matches:
        return page
    context = "\n...\n".join(m["context"] for m in matches)
    page["matched"] = sorted({f'{m["kind"]}: {m["target"]}{where}' for m in matches})
    page["score"], page["keyword_hits"], page["keywords"] = score_text(context)
    site = page["adult_site"]
    if site:
        page["score"] += config.adult_domain_weight
        page["keywords"].append({"label": "Known adult site", "weight": config.adult_domain_weight, "terms": [site]})
    page["excerpt"] = context[:800]
    return page

def rank(pages):
    return sorted(pages, key=lambda p: (p["score"], p["keyword_hits"]), reverse=True)

def cleanup(pages):
    hits = [p for p in pages if p["matched"] and p["score"] >= config.min_score]
    flagged = [p for p in pages if p["adult_site"] and p not in hits]
    for p in flagged:
        site = f"Known adult site ({p['adult_site']})"
        if p.get("error") or not p.get("file"):
            p["flag"] = f"{site}: page could not be read ({p.get('error') or 'no copy saved'})"
        elif not p["matched"]:
            p["flag"] = f"{site}: subject not found on the saved page (it may be behind an age check)"
        else:
            p["flag"] = f"{site}: mentions the subject but scored under {config.min_score}"
    keep = hits + flagged
    if config.keep_all_pages:
        return keep
    for p in pages:
        if p.get("file") and p not in keep:
            Path(p["file"]).unlink(missing_ok=True)
            p["file"] = None
    return keep