SerpAdCrawler - Quick guide
===========================

Searches Google (through SerpApi) for phone numbers and addresses, downloads the pages it finds,
and lists the pages where keywords appear near the phone number or address. It points you to pages
worth looking at; it does not decide what a page is.


Before you start
----------------
- You need a SerpApi API key. Each Google results page the program gets costs 1 SerpApi search credit.
- Put SerpAdCrawler.exe in a folder of its own that you can save files in, such as
  Documents\SerpAdCrawler. Do not put it in Program Files: the program saves its settings,
  results and cache next to the .exe.
- The default settings are tailored towards illicit massage parlors. If your target is a different kind of 
  business, change the values for "words added to every search" to the type of business you are wishing to find


First launch
------------
Windows may show "Windows protected your PC" because the program isn't from a known publisher.
Click "More info", check that the file is SerpAdCrawler.exe, then click "Run anyway".
If your antivirus blocks it, contact whoever sent you the program.


Running a search
----------------
1. Paste your SerpApi key at the top and click "Check key". It shows how many searches you have left.
   The key is not saved; you enter it each time you open the program.
2. On the Search tab, enter phone numbers (one per line, any format) and/or addresses
   (street and city are required, state is optional). Click Add for each address.
3. Click "Run search". Progress shows in the box below. "Stop" ends the search after the
   current step.
4. When it finishes, the Results tab opens.


Results
-------
- Each run is listed with its hit pages underneath, highest score first.
- Click a hit to see why it was listed: which phone/address matched, which keywords were found,
  and the text around the match.
- Double-click a hit (or "Open page in browser") to open the live page.
  "Open saved copy" opens the copy saved during the search.
- "Add site to skip list" stops a site from being downloaded in future searches.
  "Add site to adult list" adds points to pages from that site, and always returns instances
  of that site in future searches.


Evidence files
--------------
Every search is saved in its own folder under "output" (named by date and time), containing:
- report.json   - every page found, why it was or wasn't a hit, and the settings used
- pages\        - saved copies of the hit pages
- manifest.json - the SHA-256 of every file in the folder

After each run, click the run in the Results tab and use "Copy manifest hash".
Record that hash in the case file. If the manifest's hash still matches later,
none of the files in that run folder have been changed.

If a search was stopped partway, its folder has no report.json or manifest and should not be used.


Settings
--------
The Settings tab controls what is searched, keyword categories and weights, the minimum score,
the skip and adult site lists, and the cache. Click "Save settings" to apply changes. They are saved
in settings.json next to the .exe and are used every time the program opens.
"Reset to defaults" puts everything back to how the program was shipped.

The cache reuses searches and pages from the last 24 hours (by default), so running the same search
again soon costs no credits. Turn it off in Settings to always get fresh copies.


Have a Problem?
---------------
Reach out to:
max.bowling@implicitgood.com

please include the text from the output box, as well as the report file with your message. Happy hunting!
